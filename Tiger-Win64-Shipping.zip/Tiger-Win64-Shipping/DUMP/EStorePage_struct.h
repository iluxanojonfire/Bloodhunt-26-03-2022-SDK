// UserDefinedEnum EStorePage.EStorePage
enum class EStorePage : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator2 = 1,
	NewEnumerator1 = 2,
	EStorePage_MAX = 3
};

