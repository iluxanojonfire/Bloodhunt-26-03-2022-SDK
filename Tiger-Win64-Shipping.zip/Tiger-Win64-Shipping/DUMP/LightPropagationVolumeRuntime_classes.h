// Class LightPropagationVolumeRuntime.LightPropagationVolumeBlendable
// Size: 0x78 (Inherited: 0x28)
struct ULightPropagationVolumeBlendable : UObject {
	char pad_28[0x8]; // 0x28(0x08)
	struct FLightPropagationVolumeSettings Settings; // 0x30(0x40)
	float BlendWeight; // 0x70(0x04)
	char pad_74[0x4]; // 0x74(0x04)
};

