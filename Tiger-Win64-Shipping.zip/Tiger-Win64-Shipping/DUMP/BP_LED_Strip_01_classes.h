// BlueprintGeneratedClass BP_LED_Strip_01.BP_LED_Strip_01_C
// Size: 0x291 (Inherited: 0x280)
struct ABP_LED_Strip_01_C : ABP_LightMaster_C {
	struct UStaticMeshComponent* SM_LED_Lamp_05; // 0x280(0x08)
	float LightIntensity; // 0x288(0x04)
	float Attenuation radius; // 0x28c(0x04)
	bool Movable or static; // 0x290(0x01)

	void LightSetup(struct URectLightComponent* Light); // Function BP_LED_Strip_01.BP_LED_Strip_01_C.LightSetup // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x18490f0
	void UserConstructionScript(); // Function BP_LED_Strip_01.BP_LED_Strip_01_C.UserConstructionScript // (Event|Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x18490f0
};

