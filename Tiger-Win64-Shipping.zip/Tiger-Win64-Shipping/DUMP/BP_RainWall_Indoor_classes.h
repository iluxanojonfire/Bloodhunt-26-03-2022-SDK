// BlueprintGeneratedClass BP_RainWall_Indoor.BP_RainWall_Indoor_C
// Size: 0x274 (Inherited: 0x240)
struct ABP_RainWall_Indoor_C : ATBP_WeatherPS_01_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x240(0x08)
	struct UParticleSystemComponent* Drips; // 0x248(0x08)
	struct TArray<struct FParticleSysParam> ParticleParams; // 0x250(0x10)
	float RainAreaX; // 0x260(0x04)
	float RainAreaY; // 0x264(0x04)
	struct FVector Wind Direction; // 0x268(0x0c)

	void UpdateWeather(); // Function BP_RainWall_Indoor.BP_RainWall_Indoor_C.UpdateWeather // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x18490f0
	void UserConstructionScript(); // Function BP_RainWall_Indoor.BP_RainWall_Indoor_C.UserConstructionScript // (Event|Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x18490f0
	void UpdateWeatherComponents(); // Function BP_RainWall_Indoor.BP_RainWall_Indoor_C.UpdateWeatherComponents // (BlueprintCallable|BlueprintEvent) // @ game+0x18490f0
	void OnRebuild_2(); // Function BP_RainWall_Indoor.BP_RainWall_Indoor_C.OnRebuild_2 // (BlueprintCallable|BlueprintEvent) // @ game+0x18490f0
	void ExecuteUbergraph_BP_RainWall_Indoor(int32_t EntryPoint); // Function BP_RainWall_Indoor.BP_RainWall_Indoor_C.ExecuteUbergraph_BP_RainWall_Indoor // (Final|UbergraphFunction) // @ game+0x18490f0
};

