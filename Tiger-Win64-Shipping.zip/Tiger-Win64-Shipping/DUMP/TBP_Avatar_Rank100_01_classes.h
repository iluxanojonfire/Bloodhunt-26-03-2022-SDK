// BlueprintGeneratedClass TBP_Avatar_Rank100_01.TBP_Avatar_Rank100_01_C
// Size: 0x130 (Inherited: 0x130)
struct UTBP_Avatar_Rank100_01_C : UTigerCharacterIconCustomization {
};

