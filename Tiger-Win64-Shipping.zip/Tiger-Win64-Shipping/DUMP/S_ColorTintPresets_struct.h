// UserDefinedStruct S_ColorTintPresets.S_ColorTintPresets
// Size: 0x18 (Inherited: 0x00)
struct FS_ColorTintPresets {
	struct FLinearColor Color_9_78F587AD412B11B80BE90CAD86F21DE8; // 0x00(0x10)
	float Metalness_5_F11791F24F61E320E5E80EA2DE1B2C72; // 0x10(0x04)
	float Roughness_7_43E894984988D56DC97493B8DBCA7228; // 0x14(0x04)
};

