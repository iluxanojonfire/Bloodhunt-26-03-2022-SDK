// BlueprintGeneratedClass BP_FootprintsDataInterface.BP_FootprintsDataInterface_C
// Size: 0x28 (Inherited: 0x28)
struct UBP_FootprintsDataInterface_C : UObject {

	void GetMaterial(int32_t InIndex, struct UMaterialInterface*& OutMaterial); // Function BP_FootprintsDataInterface.BP_FootprintsDataInterface_C.GetMaterial // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x18490f0
	void GetMesh(int32_t InIndex, struct UStaticMesh*& OutMesh); // Function BP_FootprintsDataInterface.BP_FootprintsDataInterface_C.GetMesh // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x18490f0
};

