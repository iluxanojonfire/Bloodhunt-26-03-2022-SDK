// BlueprintGeneratedClass BP_chandelier_01.BP_chandelier_01_C
// Size: 0x298 (Inherited: 0x228)
struct ABP_chandelier_01_C : AActor {
	struct UPointLightComponent* PointLight6; // 0x228(0x08)
	struct UPointLightComponent* PointLight5; // 0x230(0x08)
	struct UPointLightComponent* PointLight4; // 0x238(0x08)
	struct UStaticMeshComponent* SM_Cath_Chandelier_Small_A; // 0x240(0x08)
	struct UPointLightComponent* PointLight3; // 0x248(0x08)
	struct UPointLightComponent* PointLight2; // 0x250(0x08)
	struct UPointLightComponent* PointLight1; // 0x258(0x08)
	struct UPointLightComponent* PointLight; // 0x260(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x268(0x08)
	float LampMedallionHeight; // 0x270(0x04)
	bool Light Toggle; // 0x274(0x01)
	char pad_275[0x3]; // 0x275(0x03)
	struct TArray<struct FLinearColor> Color; // 0x278(0x10)
	int32_t Color selector; // 0x288(0x04)
	float Intensity; // 0x28c(0x04)
	float Attenuation radius; // 0x290(0x04)
	float Cone angle; // 0x294(0x04)

	void UserConstructionScript(); // Function BP_chandelier_01.BP_chandelier_01_C.UserConstructionScript // (Event|Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x18490f0
};

