// Enum EOSSDK.EEOSConnectType
enum class EEOSConnectType : uint8 {
	OpenID = 9,
	EEOSConnectType_MAX = 10
};

// Enum EOSSDK.EEOSInterfaceResult
enum class EEOSInterfaceResult : uint8 {
	Success = 0,
	NoViolationSinceLastPoll = 1,
	ViolationDetected = 2,
	Error_UnsupportedPlatform = 3,
	Error_NoPlatform = 4,
	Error_NoConnectHandle = 5,
	Error_NoReportHandle = 6,
	Error_NoServerHandle = 7,
	Error_NoClientHandle = 8,
	Error_CallbackInitFail = 9,
	Error_InternalEosSdkFail = 10,
	Error_CallbackUnsubFail = 11,
	Error_AlreadyInitialized = 12,
	Error_NotInitialized = 13,
	Error_SessionAlreadyBegun = 14,
	Error_NoSessionRunning = 15,
	Error_UserAlreadyRegistered = 16,
	Error_NoUserRegistered = 17,
	Error_RegisteredUserLost = 18,
	Error_MismatchingUser = 19,
	Error_InvalidAccountId = 20,
	Error_UserNotFound = 21,
	Error_PollTriesExhausted = 22,
	Error_LoginPending = 23,
	Error_NoLoginPending = 24,
	Error_NullPayload = 25,
	Error_DefaultResultCode = 26,
	EEOSInterfaceResult_MAX = 27
};

// Enum EOSSDK.EEOSUserLoginStatus
enum class EEOSUserLoginStatus : uint8 {
	NotLoggedIn = 0,
	LocalUser = 1,
	LoggedIn = 2,
	UnhandledStatus = 3,
	EEOSUserLoginStatus_MAX = 4
};

// Enum EOSSDK.EEOSReportCategory
enum class EEOSReportCategory : uint8 {
	Invalid = 0,
	Cheating = 1,
	Exploiting = 2,
	OffensiveProfile = 3,
	VerbalAbuse = 4,
	Scamming = 5,
	Spamming = 6,
	Other = 7,
	EEOSReportCategory_MAX = 8
};

// Enum EOSSDK.EEOSAntiCheatActionReason
enum class EEOSAntiCheatActionReason : uint8 {
	Invalid = 0,
	InternalError = 1,
	InvalidMessage = 2,
	AuthenticaionFailed = 3,
	NullClient = 4,
	HeartbeatTimeout = 5,
	ClientViolation = 6,
	BackendViolation = 7,
	TemporaryCooldown = 8,
	TemporaryBanned = 9,
	PermanentBanned = 10,
	EEOSAntiCheatActionReason_MAX = 11
};

// Enum EOSSDK.EEOSAntiCheatAction
enum class EEOSAntiCheatAction : uint8 {
	Invalid = 0,
	RemovePlayer = 1,
	EEOSAntiCheatAction_MAX = 2
};

// ScriptStruct EOSSDK.EOSAntiCheatActionContext
// Size: 0x18 (Inherited: 0x00)
struct FEOSAntiCheatActionContext {
	struct FString ActionDetailString; // 0x00(0x10)
	enum class EEOSAntiCheatAction Action; // 0x10(0x01)
	enum class EEOSAntiCheatActionReason ActionReason; // 0x11(0x01)
	char pad_12[0x6]; // 0x12(0x06)
};

