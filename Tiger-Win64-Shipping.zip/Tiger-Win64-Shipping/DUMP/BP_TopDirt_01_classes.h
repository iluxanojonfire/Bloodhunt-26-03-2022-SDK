// BlueprintGeneratedClass BP_TopDirt_01.BP_TopDirt_01_C
// Size: 0x260 (Inherited: 0x260)
struct ABP_TopDirt_01_C : ABP_BottomDirt_01_C {
};

