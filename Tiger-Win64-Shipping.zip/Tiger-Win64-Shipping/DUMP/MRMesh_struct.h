// Enum MRMesh.EMeshTrackerVertexColorMode
enum class EMeshTrackerVertexColorMode : uint8 {
	None = 0,
	Confidence = 1,
	Block = 2,
	EMeshTrackerVertexColorMode_MAX = 3
};

// ScriptStruct MRMesh.MRMeshConfiguration
// Size: 0x01 (Inherited: 0x00)
struct FMRMeshConfiguration {
	char pad_0[0x1]; // 0x00(0x01)
};

