// Enum OnlineSubsystemTiger.ETigerMatchResult
enum class ETigerMatchResult : uint8 {
	Success = 0,
	Failure = 1,
	Timeout = 2,
	Unavailable = 3,
	KeyNotFound = 4,
	Count = 5,
	ETigerMatchResult_MAX = 6
};

// ScriptStruct OnlineSubsystemTiger.TigerHeartbeatPush
// Size: 0x01 (Inherited: 0x00)
struct FTigerHeartbeatPush {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct OnlineSubsystemTiger.TigerMatchmakingPush
// Size: 0x48 (Inherited: 0x00)
struct FTigerMatchmakingPush {
	enum class ETigerMatchResult Result; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct FString Host; // 0x08(0x10)
	int32_t Port; // 0x18(0x04)
	char pad_1C[0x4]; // 0x1c(0x04)
	struct FString GameSessionId; // 0x20(0x10)
	struct FString GameSessionToken; // 0x30(0x10)
	uint32_t MatchRequestId; // 0x40(0x04)
	char pad_44[0x4]; // 0x44(0x04)
};

// ScriptStruct OnlineSubsystemTiger.Request_CancelMatchmakingV2
// Size: 0x38 (Inherited: 0x00)
struct FRequest_CancelMatchmakingV2 {
	struct FString SESSIONTYPE; // 0x00(0x10)
	struct FString DsVersion; // 0x10(0x10)
	struct FString GAMEMODEID; // 0x20(0x10)
	uint32_t MatchRequestId; // 0x30(0x04)
	char pad_34[0x4]; // 0x34(0x04)
};

// ScriptStruct OnlineSubsystemTiger.Request_CancelMatchmaking
// Size: 0x28 (Inherited: 0x00)
struct FRequest_CancelMatchmaking {
	struct FString SESSIONTYPE; // 0x00(0x10)
	struct FString DsVersion; // 0x10(0x10)
	uint32_t MatchRequestId; // 0x20(0x04)
	char pad_24[0x4]; // 0x24(0x04)
};

// ScriptStruct OnlineSubsystemTiger.Response_StartMatchmaking
// Size: 0x18 (Inherited: 0x00)
struct FResponse_StartMatchmaking {
	bool OK; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct FString Error; // 0x08(0x10)
};

// ScriptStruct OnlineSubsystemTiger.Request_StartMatchmaking
// Size: 0x58 (Inherited: 0x00)
struct FRequest_StartMatchmaking {
	struct FString SESSIONTYPE; // 0x00(0x10)
	struct FString DsVersion; // 0x10(0x10)
	struct FString MATCHMAKINGTOKEN; // 0x20(0x10)
	struct FString REGIONPINGS; // 0x30(0x10)
	int32_t MATCHMAKINGPLATFORM; // 0x40(0x04)
	uint32_t MatchRequestId; // 0x44(0x04)
	struct FString GAMEMODEID; // 0x48(0x10)
};

// ScriptStruct OnlineSubsystemTiger.ResponseEnvelope
// Size: 0x18 (Inherited: 0x00)
struct FResponseEnvelope {
	bool OK; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct FString Error; // 0x08(0x10)
};

