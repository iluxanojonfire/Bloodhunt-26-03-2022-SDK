// Class OnlineSubsystemTiger.TigerOnlineSubsystemSettings
// Size: 0xd0 (Inherited: 0x38)
struct UTigerOnlineSubsystemSettings : UDeveloperSettings {
	struct FString OnlineServicesBaseUrlDev; // 0x38(0x10)
	struct FString OnlineServicesBaseUrlUatMain; // 0x48(0x10)
	struct FString OnlineServicesBaseUrlUatRelease; // 0x58(0x10)
	struct FString OnlineServicesBaseUrlUatPs5; // 0x68(0x10)
	struct FString OnlineServicesBaseUrlUatStaging; // 0x78(0x10)
	struct FString OnlineServicesBaseUrlProd; // 0x88(0x10)
	struct FString OnlineServicesBaseUrlLocal; // 0x98(0x10)
	struct FString SessionServiceUri; // 0xa8(0x10)
	int32_t MaxRequestRetries; // 0xb8(0x04)
	int32_t MatchmakingTimeoutSeconds; // 0xbc(0x04)
	struct FString DsVersion; // 0xc0(0x10)
};

