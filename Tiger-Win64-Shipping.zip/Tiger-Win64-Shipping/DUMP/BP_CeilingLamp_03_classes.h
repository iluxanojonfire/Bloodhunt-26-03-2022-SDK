// BlueprintGeneratedClass BP_CeilingLamp_03.BP_CeilingLamp_03_C
// Size: 0x2ed (Inherited: 0x280)
struct ABP_CeilingLamp_03_C : ABP_LightMaster_C {
	struct UStaticMeshComponent* SM_CeilingLamp_03_Shade; // 0x280(0x08)
	struct UStaticMeshComponent* SM_CeilingLamp_03_Socket; // 0x288(0x08)
	float Height; // 0x290(0x04)
	float AttenuationRadius; // 0x294(0x04)
	float Outer cone angle; // 0x298(0x04)
	float Inner Cone Angle; // 0x29c(0x04)
	bool Cast Shadows ; // 0x2a0(0x01)
	char pad_2A1[0x3]; // 0x2a1(0x03)
	float Light Intensity; // 0x2a4(0x04)
	struct TArray<struct UTextureLightProfile*> IES Array; // 0x2a8(0x10)
	int32_t IES; // 0x2b8(0x04)
	char pad_2BC[0x4]; // 0x2bc(0x04)
	struct TArray<struct UStaticMesh*> Mesh array; // 0x2c0(0x10)
	int32_t Select Mesh; // 0x2d0(0x04)
	char pad_2D4[0x4]; // 0x2d4(0x04)
	struct TArray<struct UMaterialInstance*> Material; // 0x2d8(0x10)
	float Volumetric intensity; // 0x2e8(0x04)
	enum class EComponentMobility Mobility; // 0x2ec(0x01)

	void UserConstructionScript(); // Function BP_CeilingLamp_03.BP_CeilingLamp_03_C.UserConstructionScript // (Event|Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x18490f0
};

