// BlueprintGeneratedClass TBP_Avatar_Graffiti_02.TBP_Avatar_Graffiti_02_C
// Size: 0x130 (Inherited: 0x130)
struct UTBP_Avatar_Graffiti_02_C : UTigerCharacterIconCustomization {
};

