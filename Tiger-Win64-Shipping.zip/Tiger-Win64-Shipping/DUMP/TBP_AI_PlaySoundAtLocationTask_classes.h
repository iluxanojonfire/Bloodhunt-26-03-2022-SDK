// BlueprintGeneratedClass TBP_AI_PlaySoundAtLocationTask.TBP_AI_PlaySoundAtLocationTask_C
// Size: 0xb8 (Inherited: 0xa8)
struct UTBP_AI_PlaySoundAtLocationTask_C : UBTTask_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa8(0x08)
	struct USoundCue* SoundCue; // 0xb0(0x08)

	void ReceiveExecute(struct AActor* OwnerActor); // Function TBP_AI_PlaySoundAtLocationTask.TBP_AI_PlaySoundAtLocationTask_C.ReceiveExecute // (Event|Protected|BlueprintEvent) // @ game+0x18490f0
	void ExecuteUbergraph_TBP_AI_PlaySoundAtLocationTask(int32_t EntryPoint); // Function TBP_AI_PlaySoundAtLocationTask.TBP_AI_PlaySoundAtLocationTask_C.ExecuteUbergraph_TBP_AI_PlaySoundAtLocationTask // (Final|UbergraphFunction) // @ game+0x18490f0
};

