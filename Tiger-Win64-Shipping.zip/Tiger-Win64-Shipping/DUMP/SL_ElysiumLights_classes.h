// BlueprintGeneratedClass SL_ElysiumLights.SL_ElysiumLights_C
// Size: 0x230 (Inherited: 0x230)
struct ASL_ElysiumLights_C : ALevelScriptActor {
};

