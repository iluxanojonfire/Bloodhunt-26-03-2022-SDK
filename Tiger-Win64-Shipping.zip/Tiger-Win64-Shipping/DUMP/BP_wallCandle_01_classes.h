// BlueprintGeneratedClass BP_wallCandle_01.BP_wallCandle_01_C
// Size: 0x258 (Inherited: 0x228)
struct ABP_wallCandle_01_C : AActor {
	struct UPointLightComponent* PointLight1_LightComponent1; // 0x228(0x08)
	struct UStaticMeshComponent* SM_VFX_CandleFlame; // 0x230(0x08)
	struct UStaticMeshComponent* SM_Ely_CandleHolder_10_StaticMeshComponent0; // 0x238(0x08)
	struct UPointLightComponent* PointLight1_LightComponent0; // 0x240(0x08)
	struct USceneComponent* SharedRoot; // 0x248(0x08)
	float Intensity; // 0x250(0x04)
	float Attenuation radius; // 0x254(0x04)

	void UserConstructionScript(); // Function BP_wallCandle_01.BP_wallCandle_01_C.UserConstructionScript // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x18490f0
};

