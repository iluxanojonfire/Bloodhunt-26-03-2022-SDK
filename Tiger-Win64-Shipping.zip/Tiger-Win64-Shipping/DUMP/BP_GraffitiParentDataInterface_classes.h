// BlueprintGeneratedClass BP_GraffitiParentDataInterface.BP_GraffitiParentDataInterface_C
// Size: 0x28 (Inherited: 0x28)
struct UBP_GraffitiParentDataInterface_C : UObject {

	void GetRandomMixedMaterial(int32_t InSeed, struct UMaterialInterface*& OutMaterial); // Function BP_GraffitiParentDataInterface.BP_GraffitiParentDataInterface_C.GetRandomMixedMaterial // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x18490f0
	void GetRandomMaterial(int32_t InSeed, struct UMaterialInterface*& OutMaterial); // Function BP_GraffitiParentDataInterface.BP_GraffitiParentDataInterface_C.GetRandomMaterial // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x18490f0
};

