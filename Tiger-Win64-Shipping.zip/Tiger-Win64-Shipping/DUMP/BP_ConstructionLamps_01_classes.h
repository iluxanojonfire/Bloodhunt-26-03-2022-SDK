// BlueprintGeneratedClass BP_ConstructionLamps_01.BP_ConstructionLamps_01_C
// Size: 0x2d0 (Inherited: 0x280)
struct ABP_ConstructionLamps_01_C : ABP_LightMaster_C {
	struct UStaticMeshComponent* SM_Construction_Lamp_Small_01; // 0x280(0x08)
	struct TArray<struct FTransform> SpotTrans; // 0x288(0x10)
	int32_t MeshSwitch; // 0x298(0x04)
	float LightIntensity; // 0x29c(0x04)
	float Outer cone angle; // 0x2a0(0x04)
	float AttRadius; // 0x2a4(0x04)
	float Vol Intensity; // 0x2a8(0x04)
	bool ShadowCasting; // 0x2ac(0x01)
	char pad_2AD[0x3]; // 0x2ad(0x03)
	float SpotRotation; // 0x2b0(0x04)
	bool off; // 0x2b4(0x01)
	char pad_2B5[0xb]; // 0x2b5(0x0b)
	struct FVector4 Color; // 0x2c0(0x10)

	void SetCustomPrimitiveData(); // Function BP_ConstructionLamps_01.BP_ConstructionLamps_01_C.SetCustomPrimitiveData // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x18490f0
	void UserConstructionScript(); // Function BP_ConstructionLamps_01.BP_ConstructionLamps_01_C.UserConstructionScript // (Event|Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x18490f0
};

