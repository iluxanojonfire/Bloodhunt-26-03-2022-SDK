// BlueprintGeneratedClass BP_Env_AreaFog.BP_Env_AreaFog_C
// Size: 0x258 (Inherited: 0x228)
struct ABP_Env_AreaFog_C : AActor {
	struct UParticleSystemComponent* ParticleSystem; // 0x228(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x230(0x08)
	struct FLinearColor Color; // 0x238(0x10)
	float Alpha; // 0x248(0x04)
	float SpawnHight; // 0x24c(0x04)
	float SpawnArea; // 0x250(0x04)
	float Particle Size; // 0x254(0x04)
};

