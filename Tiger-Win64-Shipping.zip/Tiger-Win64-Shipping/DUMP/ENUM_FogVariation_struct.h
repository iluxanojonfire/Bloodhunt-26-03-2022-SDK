// UserDefinedEnum ENUM_FogVariation.ENUM_FogVariation
enum class ENUM_FogVariation : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator2 = 1,
	NewEnumerator3 = 2,
	ENUM_MAX = 3
};

