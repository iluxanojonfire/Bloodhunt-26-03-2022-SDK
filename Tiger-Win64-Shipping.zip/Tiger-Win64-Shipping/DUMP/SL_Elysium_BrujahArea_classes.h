// BlueprintGeneratedClass SL_Elysium_BrujahArea.SL_Elysium_BrujahArea_C
// Size: 0x230 (Inherited: 0x230)
struct ASL_Elysium_BrujahArea_C : ALevelScriptActor {
};

