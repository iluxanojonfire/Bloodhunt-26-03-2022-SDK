// UserDefinedEnum ENUM_MovementMode.ENUM_MovementMode
enum class ENUM_MovementMode : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	ENUM_MAX = 2
};

