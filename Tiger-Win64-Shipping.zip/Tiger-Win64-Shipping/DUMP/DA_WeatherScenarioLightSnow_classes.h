// BlueprintGeneratedClass DA_WeatherScenarioLightSnow.DA_WeatherScenarioLightSnow_C
// Size: 0xf5 (Inherited: 0xf5)
struct UDA_WeatherScenarioLightSnow_C : UDA_WeatherScenario_C {
};

