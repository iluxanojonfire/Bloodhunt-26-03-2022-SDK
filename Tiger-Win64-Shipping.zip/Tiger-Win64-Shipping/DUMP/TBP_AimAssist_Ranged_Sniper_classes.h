// BlueprintGeneratedClass TBP_AimAssist_Ranged_Sniper.TBP_AimAssist_Ranged_Sniper_C
// Size: 0x200 (Inherited: 0x200)
struct UTBP_AimAssist_Ranged_Sniper_C : UTBP_AimAssist_Ranged_C {
};

