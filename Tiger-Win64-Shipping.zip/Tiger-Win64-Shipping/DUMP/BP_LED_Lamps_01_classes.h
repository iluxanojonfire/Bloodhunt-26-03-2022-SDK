// BlueprintGeneratedClass BP_LED_Lamps_01.BP_LED_Lamps_01_C
// Size: 0x300 (Inherited: 0x280)
struct ABP_LED_Lamps_01_C : ABP_LightMaster_C {
	struct URectLightComponent* RectLight; // 0x280(0x08)
	struct UStaticMeshComponent* SM_LED_Lamp_04; // 0x288(0x08)
	struct UStaticMeshComponent* SM_LED_Lamp_03; // 0x290(0x08)
	struct UStaticMeshComponent* SM_LED_Lamp_01; // 0x298(0x08)
	struct UStaticMeshComponent* SM_LED_Lamp_02; // 0x2a0(0x08)
	int32_t Type of Lightmesh; // 0x2a8(0x04)
	char pad_2AC[0x4]; // 0x2ac(0x04)
	struct TArray<struct FVector> LightPositions; // 0x2b0(0x10)
	float LightIntensity; // 0x2c0(0x04)
	float Attenuation Range; // 0x2c4(0x04)
	float Attenuation Range_Moveable; // 0x2c8(0x04)
	bool off; // 0x2cc(0x01)
	char pad_2CD[0x3]; // 0x2cd(0x03)
	float VolumetricScatteringIntensity; // 0x2d0(0x04)
	bool Movable; // 0x2d4(0x01)
	char pad_2D5[0x3]; // 0x2d5(0x03)
	struct TSoftClassPtr<UObject> LEDLampsData; // 0x2d8(0x28)

	void SetMaterialLightsOff(struct UPrimitiveComponent* InMesh, struct UMaterialInterface* InMaterial); // Function BP_LED_Lamps_01.BP_LED_Lamps_01_C.SetMaterialLightsOff // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x18490f0
	void RemoveLampComponentsThatAren'tUsed(); // Function BP_LED_Lamps_01.BP_LED_Lamps_01_C.RemoveLampComponentsThatAren'tUsed // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x18490f0
	void UserConstructionScript(); // Function BP_LED_Lamps_01.BP_LED_Lamps_01_C.UserConstructionScript // (Event|Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x18490f0
};

