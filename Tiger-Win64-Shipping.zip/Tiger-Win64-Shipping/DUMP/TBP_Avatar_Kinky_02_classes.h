// BlueprintGeneratedClass TBP_Avatar_Kinky_02.TBP_Avatar_Kinky_02_C
// Size: 0x130 (Inherited: 0x130)
struct UTBP_Avatar_Kinky_02_C : UTigerCharacterIconCustomization {
};

