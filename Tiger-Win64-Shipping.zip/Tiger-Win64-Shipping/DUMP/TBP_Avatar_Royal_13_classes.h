// BlueprintGeneratedClass TBP_Avatar_Royal_13.TBP_Avatar_Royal_12_C
// Size: 0x130 (Inherited: 0x130)
struct UTBP_Avatar_Royal_12_C : UTigerCharacterIconCustomization {
};

