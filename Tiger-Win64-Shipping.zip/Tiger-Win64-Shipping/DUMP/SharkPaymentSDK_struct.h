// Enum SharkPaymentSDK.EShPaymentResult
enum class EShPaymentResult : int32 {
	NOT_SUPPORTED = -2,
	GENERAL_ERROR = -1,
	OK = 0,
	Cancel = 1,
	LOGIN_EXPIRED = 2,
	DISCONNECTED = 3,
	CONNECTION_ERROR = 4,
	ABORTED_DUE_TO_FRAUD = 5,
	PAYMENT_SYSTEM_FAILED = 6,
	THIRDPARTY_NOT_ENABLED = 7,
	EShPaymentResult_MAX = 8
};

// ScriptStruct SharkPaymentSDK.ShReponse_Finalize
// Size: 0x10 (Inherited: 0x00)
struct FShReponse_Finalize {
	struct FString Status; // 0x00(0x10)
};

// ScriptStruct SharkPaymentSDK.ShRequest_Finalize
// Size: 0x20 (Inherited: 0x00)
struct FShRequest_Finalize {
	struct FString Ticket; // 0x00(0x10)
	struct FString TransactionId; // 0x10(0x10)
};

// ScriptStruct SharkPaymentSDK.ShResponse_CreateTicket
// Size: 0x10 (Inherited: 0x00)
struct FShResponse_CreateTicket {
	struct FString Ticket; // 0x00(0x10)
};

// ScriptStruct SharkPaymentSDK.ShRequest_CreateTicket
// Size: 0x38 (Inherited: 0x00)
struct FShRequest_CreateTicket {
	struct FString AppId; // 0x00(0x10)
	struct FString userId; // 0x10(0x10)
	struct FString AuthCode; // 0x20(0x10)
	char PlatformBackend; // 0x30(0x01)
	char pad_31[0x7]; // 0x31(0x07)
};

