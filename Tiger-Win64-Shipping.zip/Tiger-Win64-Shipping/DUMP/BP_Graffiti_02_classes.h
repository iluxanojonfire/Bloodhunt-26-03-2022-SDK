// BlueprintGeneratedClass BP_Graffiti_02.BP_Graffiti_02_C
// Size: 0x25c (Inherited: 0x228)
struct ABP_Graffiti_02_C : AActor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x228(0x08)
	struct UStaticMeshComponent* SM_Graffiti_Decal_01; // 0x230(0x08)
	struct TArray<struct FLinearColor> Color; // 0x238(0x10)
	float FakeIntensity; // 0x248(0x04)
	int32_t RandomInt; // 0x24c(0x04)
	bool PaintOver; // 0x250(0x01)
	char pad_251[0x3]; // 0x251(0x03)
	struct FColor PaintOverColor; // 0x254(0x04)
	int32_t Sort Priority; // 0x258(0x04)

	void SetCustomPrimitiveData(); // Function BP_Graffiti_02.BP_Graffiti_02_C.SetCustomPrimitiveData // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x18490f0
	void UserConstructionScript(); // Function BP_Graffiti_02.BP_Graffiti_02_C.UserConstructionScript // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x18490f0
	void ReceiveBeginPlay(); // Function BP_Graffiti_02.BP_Graffiti_02_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x18490f0
	void ExecuteUbergraph_BP_Graffiti_02(int32_t EntryPoint); // Function BP_Graffiti_02.BP_Graffiti_02_C.ExecuteUbergraph_BP_Graffiti_02 // (Final|UbergraphFunction) // @ game+0x18490f0
};

