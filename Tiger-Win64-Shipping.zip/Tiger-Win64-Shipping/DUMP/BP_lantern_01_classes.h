// BlueprintGeneratedClass BP_lantern_01.BP_lantern_01_C
// Size: 0x261 (Inherited: 0x228)
struct ABP_lantern_01_C : AActor {
	struct UStaticMeshComponent* SM_lantern_01; // 0x228(0x08)
	struct UTigerSpotLightComponent* TigerSpotLight; // 0x230(0x08)
	struct UStaticMeshComponent* SM_VFX_CandleFlame_02; // 0x238(0x08)
	struct UPointLightComponent* PointLight; // 0x240(0x08)
	int32_t Select Mesh; // 0x248(0x04)
	char pad_24C[0x4]; // 0x24c(0x04)
	struct TArray<struct UStaticMesh*> Mesh; // 0x250(0x10)
	bool off; // 0x260(0x01)

	void UserConstructionScript(); // Function BP_lantern_01.BP_lantern_01_C.UserConstructionScript // (Event|Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x18490f0
};

