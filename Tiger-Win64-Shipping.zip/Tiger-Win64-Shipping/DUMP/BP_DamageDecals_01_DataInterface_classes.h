// BlueprintGeneratedClass BP_DamageDecals_01_DataInterface.BP_DamageDecals_01_DataInterface_C
// Size: 0x28 (Inherited: 0x28)
struct UBP_DamageDecals_01_DataInterface_C : UObject {

	void GetMesh(int32_t InIndex, struct UStaticMesh*& OutMesh); // Function BP_DamageDecals_01_DataInterface.BP_DamageDecals_01_DataInterface_C.GetMesh // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x18490f0
};

