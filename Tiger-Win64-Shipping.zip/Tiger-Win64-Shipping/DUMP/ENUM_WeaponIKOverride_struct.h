// UserDefinedEnum ENUM_WeaponIKOverride.ENUM_WeaponIKOverride
enum class ENUM_WeaponIKOverride : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	NewEnumerator2 = 2,
	NewEnumerator3 = 3,
	ENUM_MAX = 4
};

