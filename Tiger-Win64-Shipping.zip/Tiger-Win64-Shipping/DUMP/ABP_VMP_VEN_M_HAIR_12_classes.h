// AnimBlueprintGeneratedClass ABP_VMP_VEN_M_HAIR_12.ABP_VMP_VEN_M_HAIR_11_C
// Size: 0x3a80 (Inherited: 0x2c0)
struct UABP_VMP_VEN_M_HAIR_11_C : UAnimInstance {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2c0(0x08)
	char pad_2C8[0x8]; // 0x2c8(0x08)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_13; // 0x2d0(0x440)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_12; // 0x710(0x440)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_11; // 0xb50(0x440)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_10; // 0xf90(0x440)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_9; // 0x13d0(0x440)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace; // 0x1810(0x20)
	struct FAnimNode_Root AnimGraphNode_Root; // 0x1830(0x30)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_8; // 0x1860(0x440)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_7; // 0x1ca0(0x440)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace; // 0x20e0(0x20)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_6; // 0x2100(0x440)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_5; // 0x2540(0x440)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_4; // 0x2980(0x440)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_3; // 0x2dc0(0x440)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics_2; // 0x3200(0x440)
	struct FAnimNode_AnimDynamics AnimGraphNode_AnimDynamics; // 0x3640(0x440)

	void AnimGraph(struct FPoseLink& AnimGraph); // Function ABP_VMP_VEN_M_HAIR_12.ABP_VMP_VEN_M_HAIR_11_C.AnimGraph // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x18490f0
	void ExecuteUbergraph_ABP_VMP_VEN_M_HAIR_12(int32_t EntryPoint); // Function ABP_VMP_VEN_M_HAIR_12.ABP_VMP_VEN_M_HAIR_11_C.ExecuteUbergraph_ABP_VMP_VEN_M_HAIR_12 // (Final|UbergraphFunction) // @ game+0x18490f0
};

