// BlueprintGeneratedClass BP_LED_Lamps_01_Data.BP_LED_Lamps_01_Data_C
// Size: 0x78 (Inherited: 0x78)
struct UBP_LED_Lamps_01_Data_C : UBP_LightMasterData_C {
};

