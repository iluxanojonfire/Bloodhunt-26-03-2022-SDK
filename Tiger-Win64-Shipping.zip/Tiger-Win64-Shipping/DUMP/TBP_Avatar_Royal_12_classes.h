// BlueprintGeneratedClass TBP_Avatar_Royal_12.TBP_Avatar_Royal_11_C
// Size: 0x130 (Inherited: 0x130)
struct UTBP_Avatar_Royal_11_C : UTigerCharacterIconCustomization {
};

