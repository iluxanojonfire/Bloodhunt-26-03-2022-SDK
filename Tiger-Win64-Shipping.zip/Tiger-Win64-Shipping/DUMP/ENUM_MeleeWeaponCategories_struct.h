// UserDefinedEnum ENUM_MeleeWeaponCategories.ENUM_MeleeWeaponCategories
enum class ENUM_MeleeWeaponCategories : uint8 {
	NewEnumerator15 = 0,
	NewEnumerator0 = 1,
	NewEnumerator1 = 2,
	NewEnumerator2 = 3,
	NewEnumerator10 = 4,
	NewEnumerator12 = 5,
	NewEnumerator11 = 6,
	NewEnumerator17 = 7,
	ENUM_MAX = 8
};

