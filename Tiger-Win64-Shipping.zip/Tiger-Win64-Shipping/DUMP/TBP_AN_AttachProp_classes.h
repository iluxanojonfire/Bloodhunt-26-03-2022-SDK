// BlueprintGeneratedClass TBP_AN_AttachProp.TBP_AN_AttachProp_C
// Size: 0x40 (Inherited: 0x38)
struct UTBP_AN_AttachProp_C : UAnimNotify {
	struct FName AttachIdentifier; // 0x38(0x08)

	bool Received_Notify(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function TBP_AN_AttachProp.TBP_AN_AttachProp_C.Received_Notify // (Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|Const) // @ game+0x18490f0
};

