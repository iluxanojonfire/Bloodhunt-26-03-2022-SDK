// BlueprintGeneratedClass DirectionalStyle.DirectionalStyle_C
// Size: 0x49 (Inherited: 0x48)
struct UDirectionalStyle_C : UTigerWeaponCycleStyle {
	enum class ETigerWeaponSlot OutWeaponSlot; // 0x48(0x01)

	enum class ETigerWeaponSlot DetermineNextWeaponSlot(struct ATigerPlayerController* InPlayerController, enum class ETigerWeaponCycleDirection InDirection); // Function DirectionalStyle.DirectionalStyle_C.DetermineNextWeaponSlot // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x18490f0
};

