// BlueprintGeneratedClass SL_Elysium_ModelViewer.SL_Elysium_ModelViewer_C
// Size: 0x230 (Inherited: 0x230)
struct ASL_Elysium_ModelViewer_C : ALevelScriptActor {
};

