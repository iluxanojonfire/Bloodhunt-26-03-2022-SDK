// UserDefinedEnum ENUM_WallSlideDirection.ENUM_WallSlideDirection
enum class ENUM_WallSlideDirection : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	NewEnumerator2 = 2,
	ENUM_MAX = 3
};

