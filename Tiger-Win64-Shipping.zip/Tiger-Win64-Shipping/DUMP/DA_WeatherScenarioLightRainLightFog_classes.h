// BlueprintGeneratedClass DA_WeatherScenarioLightRainLightFog.DA_WeatherScenarioLightRainLightFog_C
// Size: 0xf5 (Inherited: 0xf5)
struct UDA_WeatherScenarioLightRainLightFog_C : UDA_WeatherScenario_C {
};

