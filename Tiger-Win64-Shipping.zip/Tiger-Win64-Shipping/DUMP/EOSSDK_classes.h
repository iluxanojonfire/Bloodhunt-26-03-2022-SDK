// Class EOSSDK.EOSSdkSettings
// Size: 0x58 (Inherited: 0x38)
struct UEOSSdkSettings : UDeveloperSettings {
	struct FString ProductName; // 0x38(0x10)
	struct FString ProductVersion; // 0x48(0x10)
};

// Class EOSSDK.EOSPlatformClientSettings
// Size: 0x58 (Inherited: 0x38)
struct UEOSPlatformClientSettings : UDeveloperSettings {
	struct FString ClientId; // 0x38(0x10)
	struct FString ClientSecret; // 0x48(0x10)
};

// Class EOSSDK.EOSPlatformSettings
// Size: 0x78 (Inherited: 0x38)
struct UEOSPlatformSettings : UDeveloperSettings {
	struct FString DeploymentId; // 0x38(0x10)
	struct FString EncryptionKey; // 0x48(0x10)
	struct FString ProductId; // 0x58(0x10)
	struct FString SandboxId; // 0x68(0x10)
};

// Class EOSSDK.EOSUserComponent
// Size: 0x138 (Inherited: 0xb0)
struct UEOSUserComponent : UActorComponent {
	char pad_B0[0x88]; // 0xb0(0x88)

	void Server_ReceiveConnectInfo(struct FString InToken, struct FString InID); // Function EOSSDK.EOSUserComponent.Server_ReceiveConnectInfo // (Net|NetReliableNative|Event|Public|NetServer) // @ game+0xcf4ab0
	void Server_ReceiveAntiCheatData(struct TArray<char> InByteArray); // Function EOSSDK.EOSUserComponent.Server_ReceiveAntiCheatData // (Net|NetReliableNative|Event|Public|NetServer) // @ game+0xcf4a10
	void Client_RequestConnectInfo(); // Function EOSSDK.EOSUserComponent.Client_RequestConnectInfo // (Net|NetReliableNative|Event|Public|NetClient) // @ game+0xcf49f0
	void Client_ReceiveAntiCheatData(struct TArray<char> InByteArray); // Function EOSSDK.EOSUserComponent.Client_ReceiveAntiCheatData // (Net|NetReliableNative|Event|Public|NetClient) // @ game+0xcf4950
};

