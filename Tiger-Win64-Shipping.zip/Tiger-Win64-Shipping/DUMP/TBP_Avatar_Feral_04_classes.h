// BlueprintGeneratedClass TBP_Avatar_Feral_04.TBP_Avatar_Feral_04_C
// Size: 0x130 (Inherited: 0x130)
struct UTBP_Avatar_Feral_04_C : UTigerCharacterIconCustomization {
};

