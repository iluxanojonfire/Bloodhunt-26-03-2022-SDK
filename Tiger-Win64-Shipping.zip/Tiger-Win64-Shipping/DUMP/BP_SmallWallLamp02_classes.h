// BlueprintGeneratedClass BP_SmallWallLamp02.BP_SmallWallLamp02_C
// Size: 0x2a6 (Inherited: 0x280)
struct ABP_SmallWallLamp02_C : ABP_LightMaster_C {
	struct UStaticMeshComponent* Wall_Mounted_Light; // 0x280(0x08)
	struct TArray<struct FTransform> PointlightTransform; // 0x288(0x10)
	float LightIntensity; // 0x298(0x04)
	int32_t LightMesh; // 0x29c(0x04)
	float AttenuationRadius; // 0x2a0(0x04)
	bool Static?; // 0x2a4(0x01)
	bool ShadowCasting; // 0x2a5(0x01)

	void UserConstructionScript(); // Function BP_SmallWallLamp02.BP_SmallWallLamp02_C.UserConstructionScript // (Event|Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x18490f0
};

