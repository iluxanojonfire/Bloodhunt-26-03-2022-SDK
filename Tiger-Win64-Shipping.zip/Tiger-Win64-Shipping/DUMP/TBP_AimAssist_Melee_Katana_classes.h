// BlueprintGeneratedClass TBP_AimAssist_Melee_Katana.TBP_AimAssist_Melee_Katana_C
// Size: 0x200 (Inherited: 0x200)
struct UTBP_AimAssist_Melee_Katana_C : UTBP_AimAssist_Melee_C {
};

