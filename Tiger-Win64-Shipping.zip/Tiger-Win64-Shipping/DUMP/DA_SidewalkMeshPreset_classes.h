// BlueprintGeneratedClass DA_SidewalkMeshPreset.DA_SidewalkMeshPreset_C
// Size: 0x40 (Inherited: 0x30)
struct UDA_SidewalkMeshPreset_C : UPrimaryDataAsset {
	struct TArray<struct UStaticMesh*> Meshes; // 0x30(0x10)
};

