// UserDefinedEnum ETigerQuestWidgetType.ETigerQuestWidgetType
enum class ETigerQuestWidgetType : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	NewEnumerator2 = 2,
	ETigerQuestWidgetType_MAX = 3
};

