// BlueprintGeneratedClass TBP_AI_UpdateBloodDrainedTimerService.TBP_AI_UpdateBloodDrainedTimerService_C
// Size: 0x78 (Inherited: 0x78)
struct UTBP_AI_UpdateBloodDrainedTimerService_C : UTigerAIUpdateBloodDrainedService {
};

