// UserDefinedEnum ENUM_RangedWeaponCategories.ENUM_RangedWeaponCategories
enum class ENUM_RangedWeaponCategories : uint8 {
	NewEnumerator30 = 0,
	NewEnumerator0 = 1,
	NewEnumerator1 = 2,
	NewEnumerator3 = 3,
	NewEnumerator4 = 4,
	NewEnumerator5 = 5,
	NewEnumerator6 = 6,
	NewEnumerator7 = 7,
	NewEnumerator10 = 8,
	NewEnumerator15 = 9,
	NewEnumerator22 = 10,
	NewEnumerator23 = 11,
	NewEnumerator27 = 12,
	NewEnumerator28 = 13,
	NewEnumerator29 = 14,
	NewEnumerator31 = 15,
	NewEnumerator32 = 16,
	NewEnumerator33 = 17,
	ENUM_MAX = 18
};

