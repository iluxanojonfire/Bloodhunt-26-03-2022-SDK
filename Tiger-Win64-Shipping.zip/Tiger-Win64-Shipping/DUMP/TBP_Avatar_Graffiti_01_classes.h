// BlueprintGeneratedClass TBP_Avatar_Graffiti_01.TBP_Avatar_Graffiti_01_C
// Size: 0x130 (Inherited: 0x130)
struct UTBP_Avatar_Graffiti_01_C : UTigerCharacterIconCustomization {
};

