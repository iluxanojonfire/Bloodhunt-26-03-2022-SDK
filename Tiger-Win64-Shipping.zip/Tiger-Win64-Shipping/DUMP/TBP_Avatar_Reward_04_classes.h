// BlueprintGeneratedClass TBP_Avatar_Reward_04.TBP_Avatar_Reward_04_C
// Size: 0x130 (Inherited: 0x130)
struct UTBP_Avatar_Reward_04_C : UTigerCharacterIconCustomization {
};

