// BlueprintGeneratedClass BP_GraffitiParent.BP_GraffitiParent_C
// Size: 0x24c (Inherited: 0x228)
struct ABP_GraffitiParent_C : AActor {
	struct USceneComponent* DefaultSceneRoot; // 0x228(0x08)
	struct TArray<struct FColor> ParentColor; // 0x230(0x10)
	struct UBP_GraffitiParentDataInterface_C* GraffitiDataCDO; // 0x240(0x08)
	int32_t RandomFromWorld; // 0x248(0x04)

	void RandomBoolFromWorld(int32_t InSeed, bool& OutValue); // Function BP_GraffitiParent.BP_GraffitiParent_C.RandomBoolFromWorld // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x18490f0
	void InitializeRandomFromWorld(); // Function BP_GraffitiParent.BP_GraffitiParent_C.InitializeRandomFromWorld // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x18490f0
	void UserConstructionScript(); // Function BP_GraffitiParent.BP_GraffitiParent_C.UserConstructionScript // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x18490f0
};

