// Enum OnlineSubsystemSharkmob.EAccountThirdPartyErrorCode
enum class EAccountThirdPartyErrorCode : uint8 {
	AccountServiceError = 0,
	AccountServiceConnectionError = 1,
	AccountDoesNotExist = 2,
	EmailAlreadyInUse = 3,
	ProfanityInUsername = 4,
	InvalidVerificationCode = 5,
	UsernameUnavailable = 6,
	SharkmobAccountAlreadyLinkedToPSN = 7,
	EAccountThirdPartyErrorCode_MAX = 8
};

// Enum OnlineSubsystemSharkmob.EAccountErrorType
enum class EAccountErrorType : uint8 {
	Native = 0,
	ThirdParty = 1,
	EAccountErrorType_MAX = 2
};

// ScriptStruct OnlineSubsystemSharkmob.AccountRegistrationDataSharkmob
// Size: 0x50 (Inherited: 0x00)
struct FAccountRegistrationDataSharkmob {
	struct FString Email; // 0x00(0x10)
	struct FString Password; // 0x10(0x10)
	int32_t RegionId; // 0x20(0x04)
	char pad_24[0x4]; // 0x24(0x04)
	struct FString UserName; // 0x28(0x10)
	struct FString VerificationCode; // 0x38(0x10)
	bool RecieveNewsletterEmail; // 0x48(0x01)
	char pad_49[0x7]; // 0x49(0x07)
};

// ScriptStruct OnlineSubsystemSharkmob.LoginResultSharkmob
// Size: 0xb0 (Inherited: 0x50)
struct FLoginResultSharkmob : FAccountRegistrationDataSharkmob {
	struct FString OpenId; // 0x50(0x10)
	struct FString Token; // 0x60(0x10)
	struct FString PfKey; // 0x70(0x10)
	struct FString Pf; // 0x80(0x10)
	struct FString SharkmobToken; // 0x90(0x10)
	struct FString OSSValue; // 0xa0(0x10)
};

// ScriptStruct OnlineSubsystemSharkmob.INTLChannelInfoSharkmob
// Size: 0x40 (Inherited: 0x00)
struct FINTLChannelInfoSharkmob {
	struct FString steamid; // 0x00(0x10)
	struct FString userId; // 0x10(0x10)
	struct FString issuerId; // 0x20(0x10)
	struct FINTLMapInfoSharkmob map_info; // 0x30(0x10)
};

// ScriptStruct OnlineSubsystemSharkmob.INTLMapInfoSharkmob
// Size: 0x10 (Inherited: 0x00)
struct FINTLMapInfoSharkmob {
	struct FString sacc_token; // 0x00(0x10)
};

