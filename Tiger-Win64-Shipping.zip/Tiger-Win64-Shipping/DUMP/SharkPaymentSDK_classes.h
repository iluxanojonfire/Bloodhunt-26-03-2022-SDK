// Class SharkPaymentSDK.ShPaymentSettings
// Size: 0x90 (Inherited: 0x38)
struct UShPaymentSettings : UDeveloperSettings {
	struct FString IdcInfo; // 0x38(0x10)
	struct FString OfferId; // 0x48(0x10)
	struct FString ZoneId; // 0x58(0x10)
	struct FString GoodsZoneId; // 0x68(0x10)
	struct FString ProvideType; // 0x78(0x10)
	bool LogEnabled; // 0x88(0x01)
	char pad_89[0x7]; // 0x89(0x07)
};

// Class SharkPaymentSDK.ShStoreService
// Size: 0x90 (Inherited: 0x28)
struct UShStoreService : UObject {
	char pad_28[0x68]; // 0x28(0x68)
};

