// BlueprintGeneratedClass SL_Elysium_Battlepass.SL_Elysium_Battlepass_C
// Size: 0x230 (Inherited: 0x230)
struct ASL_Elysium_Battlepass_C : ALevelScriptActor {
};

