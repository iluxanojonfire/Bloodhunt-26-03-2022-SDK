// BlueprintGeneratedClass BPI_UI_SystemMenu_CategoryInterface.BPI_UI_SystemMenu_CategoryInterface_C
// Size: 0x28 (Inherited: 0x28)
struct UBPI_UI_SystemMenu_CategoryInterface_C : UInterface {

	void ResetSettings(); // Function BPI_UI_SystemMenu_CategoryInterface.BPI_UI_SystemMenu_CategoryInterface_C.ResetSettings // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x18490f0
	void RevertChanges(); // Function BPI_UI_SystemMenu_CategoryInterface.BPI_UI_SystemMenu_CategoryInterface_C.RevertChanges // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x18490f0
	void DiscardChanges(); // Function BPI_UI_SystemMenu_CategoryInterface.BPI_UI_SystemMenu_CategoryInterface_C.DiscardChanges // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x18490f0
	void ConfirmApply(); // Function BPI_UI_SystemMenu_CategoryInterface.BPI_UI_SystemMenu_CategoryInterface_C.ConfirmApply // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x18490f0
	void ApplyChanges(bool& OutShouldShowRevertPrompt, bool& OutNeedsRestart); // Function BPI_UI_SystemMenu_CategoryInterface.BPI_UI_SystemMenu_CategoryInterface_C.ApplyChanges // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x18490f0
	void HasUnappliedChanges(bool& OutHasUnappliedChanges); // Function BPI_UI_SystemMenu_CategoryInterface.BPI_UI_SystemMenu_CategoryInterface_C.HasUnappliedChanges // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x18490f0
	void CloseCategory(); // Function BPI_UI_SystemMenu_CategoryInterface.BPI_UI_SystemMenu_CategoryInterface_C.CloseCategory // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x18490f0
	void OpenCategory(); // Function BPI_UI_SystemMenu_CategoryInterface.BPI_UI_SystemMenu_CategoryInterface_C.OpenCategory // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x18490f0
};

