// BlueprintGeneratedClass TBP_AimAssist_Default.TBP_AimAssist_Default_C
// Size: 0x200 (Inherited: 0x200)
struct UTBP_AimAssist_Default_C : UTigerAimAssistSettings {
};

