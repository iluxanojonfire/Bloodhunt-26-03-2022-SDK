// BlueprintGeneratedClass BP_CandleMultiple.BP_CandleMultiple_C
// Size: 0x2d8 (Inherited: 0x228)
struct ABP_CandleMultiple_C : AActor {
	struct UPointLightComponent* FlickeringLight1; // 0x228(0x08)
	struct UPointLightComponent* PointLight_01; // 0x230(0x08)
	struct UStaticMeshComponent* SM_VFX_CandleFlame_09; // 0x238(0x08)
	struct UStaticMeshComponent* SM_VFX_CandleFlame_08; // 0x240(0x08)
	struct UStaticMeshComponent* SM_VFX_CandleFlame_07; // 0x248(0x08)
	struct UStaticMeshComponent* SM_MERGED_BP_Candle_01_8; // 0x250(0x08)
	struct UStaticMeshComponent* SM_VFX_CandleFlame_06; // 0x258(0x08)
	struct UStaticMeshComponent* SM_VFX_CandleFlame_05; // 0x260(0x08)
	struct UStaticMeshComponent* SM_VFX_CandleFlame_04; // 0x268(0x08)
	struct UStaticMeshComponent* SM_MERGED_BP_Candle_01_7; // 0x270(0x08)
	struct UStaticMeshComponent* SM_VFX_CandleFlame_01; // 0x278(0x08)
	struct UStaticMeshComponent* SM_VFX_CandleFlame_03; // 0x280(0x08)
	struct UStaticMeshComponent* SM_VFX_CandleFlame_02; // 0x288(0x08)
	struct UStaticMeshComponent* SM_MERGED_BP_Candle_01_6; // 0x290(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x298(0x08)
	struct FColor light color; // 0x2a0(0x04)
	bool off; // 0x2a4(0x01)
	char pad_2A5[0x3]; // 0x2a5(0x03)
	int32_t Seed; // 0x2a8(0x04)
	struct FRandomStream NewVar_1; // 0x2ac(0x08)
	int32_t Amount of lights; // 0x2b4(0x04)
	float Attenuation radius; // 0x2b8(0x04)
	char pad_2BC[0x4]; // 0x2bc(0x04)
	struct UMaterialInstance* matSwitch; // 0x2c0(0x08)
	struct FVector Light transform; // 0x2c8(0x0c)
	float Intensity; // 0x2d4(0x04)

	void Random from world(int32_t NewParam, float& Scale1, float& Scale2, float& Rotate1, float& Scale3, float& Rotate2); // Function BP_CandleMultiple.BP_CandleMultiple_C.Random from world // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x18490f0
	void UserConstructionScript(); // Function BP_CandleMultiple.BP_CandleMultiple_C.UserConstructionScript // (Event|Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x18490f0
};

