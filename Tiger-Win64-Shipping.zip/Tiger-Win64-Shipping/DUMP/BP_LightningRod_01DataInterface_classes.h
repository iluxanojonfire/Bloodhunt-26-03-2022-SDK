// BlueprintGeneratedClass BP_LightningRod_01DataInterface.BP_LightningRod_01DataInterface_C
// Size: 0x28 (Inherited: 0x28)
struct UBP_LightningRod_01DataInterface_C : UObject {

	void GetMetalBottom(struct UStaticMesh*& OutMesh); // Function BP_LightningRod_01DataInterface.BP_LightningRod_01DataInterface_C.GetMetalBottom // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x18490f0
	void GetMetalTop(struct UStaticMesh*& OutMesh); // Function BP_LightningRod_01DataInterface.BP_LightningRod_01DataInterface_C.GetMetalTop // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x18490f0
	void GetMetalMiddle(int32_t InIndex, struct UStaticMesh*& OutMesh); // Function BP_LightningRod_01DataInterface.BP_LightningRod_01DataInterface_C.GetMetalMiddle // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x18490f0
};

