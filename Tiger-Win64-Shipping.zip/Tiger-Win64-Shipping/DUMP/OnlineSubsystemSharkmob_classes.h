// Class OnlineSubsystemSharkmob.AccountErrorHandler
// Size: 0x28 (Inherited: 0x28)
struct UAccountErrorHandler : UObject {

	bool IsAccountLinkingRequired(); // Function OnlineSubsystemSharkmob.AccountErrorHandler.IsAccountLinkingRequired // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0xce80f0
	int32_t GetThirdPartyErrorCode(enum class EAccountThirdPartyErrorCode InErrorEnum); // Function OnlineSubsystemSharkmob.AccountErrorHandler.GetThirdPartyErrorCode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xce8070
	struct FString GetAccountErrorMessage(int32_t InErrorCode, enum class EAccountErrorType InErrorType); // Function OnlineSubsystemSharkmob.AccountErrorHandler.GetAccountErrorMessage // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xce7f50
};

// Class OnlineSubsystemSharkmob.INTLLoginWithEmailCallbackProxy
// Size: 0x90 (Inherited: 0x30)
struct UINTLLoginWithEmailCallbackProxy : UOnlineBlueprintCallProxyBase {
	struct FMulticastInlineDelegate OnSuccess; // 0x30(0x10)
	struct FMulticastInlineDelegate OnFailure; // 0x40(0x10)
	char pad_50[0x40]; // 0x50(0x40)

	struct UINTLLoginWithEmailCallbackProxy* ConnectToINTLServiceWithEmail(struct UObject* WorldContextObject, struct FString InEmail, struct FString InPassword); // Function OnlineSubsystemSharkmob.INTLLoginWithEmailCallbackProxy.ConnectToINTLServiceWithEmail // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xce7d80
};

// Class OnlineSubsystemSharkmob.INTLLoginWithTokenCallbackProxy
// Size: 0x70 (Inherited: 0x30)
struct UINTLLoginWithTokenCallbackProxy : UOnlineBlueprintCallProxyBase {
	struct FMulticastInlineDelegate OnSuccess; // 0x30(0x10)
	struct FMulticastInlineDelegate OnFailure; // 0x40(0x10)
	char pad_50[0x20]; // 0x50(0x20)

	struct UINTLLoginWithTokenCallbackProxy* ConnectToINTLServiceWithToken(struct UObject* WorldContextObject); // Function OnlineSubsystemSharkmob.INTLLoginWithTokenCallbackProxy.ConnectToINTLServiceWithToken // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xce7ec0
};

// Class OnlineSubsystemSharkmob.INTLQueryEmailAvailabilityCallbackProxy
// Size: 0x80 (Inherited: 0x30)
struct UINTLQueryEmailAvailabilityCallbackProxy : UOnlineBlueprintCallProxyBase {
	struct FMulticastInlineDelegate OnSuccess; // 0x30(0x10)
	struct FMulticastInlineDelegate OnFailure; // 0x40(0x10)
	char pad_50[0x30]; // 0x50(0x30)

	struct UINTLQueryEmailAvailabilityCallbackProxy* QueryEmailAvailabilityWithINTL(struct UObject* WorldContextObject, struct FString InEmail); // Function OnlineSubsystemSharkmob.INTLQueryEmailAvailabilityCallbackProxy.QueryEmailAvailabilityWithINTL // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xce8110
};

// Class OnlineSubsystemSharkmob.INTLQueryUserNameAvailabilityCallbackProxy
// Size: 0x80 (Inherited: 0x30)
struct UINTLQueryUserNameAvailabilityCallbackProxy : UOnlineBlueprintCallProxyBase {
	struct FMulticastInlineDelegate OnSuccess; // 0x30(0x10)
	struct FMulticastInlineDelegate OnFailure; // 0x40(0x10)
	char pad_50[0x30]; // 0x50(0x30)

	struct UINTLQueryUserNameAvailabilityCallbackProxy* QueryUserNameAvailabilityWithINTL(struct UObject* WorldContextObject, struct FString InUsername); // Function OnlineSubsystemSharkmob.INTLQueryUserNameAvailabilityCallbackProxy.QueryUserNameAvailabilityWithINTL // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xce81f0
};

// Class OnlineSubsystemSharkmob.INTLRegisterAndLoginCallbackProxy
// Size: 0xc0 (Inherited: 0x30)
struct UINTLRegisterAndLoginCallbackProxy : UOnlineBlueprintCallProxyBase {
	struct FMulticastInlineDelegate OnSuccess; // 0x30(0x10)
	struct FMulticastInlineDelegate OnFailure; // 0x40(0x10)
	char pad_50[0x70]; // 0x50(0x70)

	struct UINTLRegisterAndLoginCallbackProxy* RegisterAndLoginToINTL(struct UObject* WorldContextObject, struct FString InEmail, struct FString InPassword, struct FString InUsername, struct FString InVerificationCode, int32_t InRegionId, bool InReceiveNewsletterEmail, struct FDateTime InBirthday); // Function OnlineSubsystemSharkmob.INTLRegisterAndLoginCallbackProxy.RegisterAndLoginToINTL // (Final|Native|Static|Public|HasDefaults|BlueprintCallable) // @ game+0xce82d0
};

// Class OnlineSubsystemSharkmob.INTLSendRegisterVerificationCodeCallbackProxy
// Size: 0x80 (Inherited: 0x30)
struct UINTLSendRegisterVerificationCodeCallbackProxy : UOnlineBlueprintCallProxyBase {
	struct FMulticastInlineDelegate OnSuccess; // 0x30(0x10)
	struct FMulticastInlineDelegate OnFailure; // 0x40(0x10)
	char pad_50[0x30]; // 0x50(0x30)

	struct UINTLSendRegisterVerificationCodeCallbackProxy* SendRegisterVerificationCode(struct UObject* WorldContextObject, struct FString InUsername); // Function OnlineSubsystemSharkmob.INTLSendRegisterVerificationCodeCallbackProxy.SendRegisterVerificationCode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xce8570
};

