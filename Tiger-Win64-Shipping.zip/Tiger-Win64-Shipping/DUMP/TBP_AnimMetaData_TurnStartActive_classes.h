// BlueprintGeneratedClass TBP_AnimMetaData_TurnStartActive.TBP_AnimMetaData_TurnStartActive_C
// Size: 0x28 (Inherited: 0x28)
struct UTBP_AnimMetaData_TurnStartActive_C : UAnimMetaData {
};

