// BlueprintGeneratedClass SL_Elysium_ArchetypeSelect.SL_Elysium_ArchetypeSelect_C
// Size: 0x230 (Inherited: 0x230)
struct ASL_Elysium_ArchetypeSelect_C : ALevelScriptActor {
};

