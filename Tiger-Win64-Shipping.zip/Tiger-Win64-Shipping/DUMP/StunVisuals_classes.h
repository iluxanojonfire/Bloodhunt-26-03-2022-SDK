// BlueprintGeneratedClass StunVisuals.StunVisuals_C
// Size: 0x238 (Inherited: 0x228)
struct AStunVisuals_C : AActor {
	struct UStaticMeshComponent* StaticMesh; // 0x228(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x230(0x08)
};

