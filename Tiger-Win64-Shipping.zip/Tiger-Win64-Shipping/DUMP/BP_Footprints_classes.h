// BlueprintGeneratedClass BP_Footprints.BP_Footprints_C
// Size: 0x238 (Inherited: 0x228)
struct ABP_Footprints_C : AActor {
	struct UStaticMeshComponent* SM_Footprints_01; // 0x228(0x08)
	int32_t FootPrintVariation; // 0x230(0x04)
	int32_t FootPrintType; // 0x234(0x04)

	void UserConstructionScript(); // Function BP_Footprints.BP_Footprints_C.UserConstructionScript // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x18490f0
};

