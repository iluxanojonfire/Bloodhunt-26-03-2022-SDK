// BlueprintGeneratedClass SL_ElysiumBenchmarking.SL_ElysiumBenchmarking_C
// Size: 0x230 (Inherited: 0x230)
struct ASL_ElysiumBenchmarking_C : ALevelScriptActor {
};

