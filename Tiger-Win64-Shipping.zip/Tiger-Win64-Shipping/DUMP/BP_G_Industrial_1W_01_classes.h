// BlueprintGeneratedClass BP_G_Industrial_1W_01.BP_G_Industrial_1W_01_C
// Size: 0x38 (Inherited: 0x38)
struct UBP_G_Industrial_1W_01_C : UTigerBuildingWallPreset {
};

