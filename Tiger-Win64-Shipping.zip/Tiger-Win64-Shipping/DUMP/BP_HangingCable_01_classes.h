// BlueprintGeneratedClass BP_HangingCable_01.BP_HangingCable_01_C
// Size: 0x25c (Inherited: 0x228)
struct ABP_HangingCable_01_C : AActor {
	struct USplineComponent* Spline; // 0x228(0x08)
	struct TArray<struct UStaticMesh*> Mesh array; // 0x230(0x10)
	float Spacing; // 0x240(0x04)
	int32_t MeshSwitch; // 0x244(0x04)
	struct TArray<struct UMaterialInstance*> Materials; // 0x248(0x10)
	int32_t ColorSwitch; // 0x258(0x04)

	void UserConstructionScript(); // Function BP_HangingCable_01.BP_HangingCable_01_C.UserConstructionScript // (Event|Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x18490f0
};

