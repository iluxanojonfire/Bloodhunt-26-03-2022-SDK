// BlueprintGeneratedClass Crossbow_Explosion_4.Crossbow_Explosion_3_C
// Size: 0x518 (Inherited: 0x510)
struct ACrossbow_Explosion_3_C : ATigerAreaEffect {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x510(0x08)

	void OnTriggerClient(); // Function Crossbow_Explosion_4.Crossbow_Explosion_3_C.OnTriggerClient // (Event|Public|BlueprintEvent) // @ game+0x18490f0
	void ExecuteUbergraph_Crossbow_Explosion_4(int32_t EntryPoint); // Function Crossbow_Explosion_4.Crossbow_Explosion_3_C.ExecuteUbergraph_Crossbow_Explosion_4 // (Final|UbergraphFunction) // @ game+0x18490f0
};

