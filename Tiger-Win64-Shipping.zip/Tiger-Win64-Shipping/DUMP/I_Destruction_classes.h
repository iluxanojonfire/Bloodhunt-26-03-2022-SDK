// BlueprintGeneratedClass I_Destruction.I_Destruction_C
// Size: 0x28 (Inherited: 0x28)
struct UI_Destruction_C : UInterface {

	void TriggerAlarm(); // Function I_Destruction.I_Destruction_C.TriggerAlarm // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x18490f0
	void StaticMeshComponentHit(struct FHitResult HitResult, struct FVector ImpactVelocity); // Function I_Destruction.I_Destruction_C.StaticMeshComponentHit // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x18490f0
};

