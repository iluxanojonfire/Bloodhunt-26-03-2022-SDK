// UserDefinedEnum ENUM_SettleType.ENUM_SettleType
enum class ENUM_SettleType : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator3 = 1,
	NewEnumerator4 = 2,
	ENUM_MAX = 3
};

