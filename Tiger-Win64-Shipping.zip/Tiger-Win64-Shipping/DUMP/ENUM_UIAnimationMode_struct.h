// UserDefinedEnum ENUM_UIAnimationMode.ENUM_UIAnimationMode
enum class ENUM_UIAnimationMode : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	ENUM_MAX = 2
};

