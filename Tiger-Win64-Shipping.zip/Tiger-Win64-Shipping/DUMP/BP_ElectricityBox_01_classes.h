// BlueprintGeneratedClass BP_ElectricityBox_01.BP_ElectricityBox_01_C
// Size: 0x278 (Inherited: 0x24c)
struct ABP_ElectricityBox_01_C : ABP_GraffitiParent_C {
	char pad_24C[0x4]; // 0x24c(0x04)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x250(0x08)
	struct UStaticMeshComponent* SM_ElectricityBox_01; // 0x258(0x08)
	bool off; // 0x260(0x01)
	bool off; // 0x261(0x01)
	char pad_262[0x6]; // 0x262(0x06)
	struct UStaticMeshComponent* CreatedStaticMesh1; // 0x268(0x08)
	struct UStaticMeshComponent* CreatedStaticMesh2; // 0x270(0x08)

	void SetCustomPrimitiveData(); // Function BP_ElectricityBox_01.BP_ElectricityBox_01_C.SetCustomPrimitiveData // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x18490f0
	void UserConstructionScript(); // Function BP_ElectricityBox_01.BP_ElectricityBox_01_C.UserConstructionScript // (Event|Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x18490f0
	void ReceiveBeginPlay(); // Function BP_ElectricityBox_01.BP_ElectricityBox_01_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x18490f0
	void ExecuteUbergraph_BP_ElectricityBox_01(int32_t EntryPoint); // Function BP_ElectricityBox_01.BP_ElectricityBox_01_C.ExecuteUbergraph_BP_ElectricityBox_01 // (Final|UbergraphFunction) // @ game+0x18490f0
};

