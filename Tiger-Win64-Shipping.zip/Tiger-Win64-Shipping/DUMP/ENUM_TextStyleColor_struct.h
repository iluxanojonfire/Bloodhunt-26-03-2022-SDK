// UserDefinedEnum ENUM_TextStyleColor.ENUM_TextStyleColor
enum class ENUM_TextStyleColor : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	NewEnumerator2 = 2,
	ENUM_MAX = 3
};

