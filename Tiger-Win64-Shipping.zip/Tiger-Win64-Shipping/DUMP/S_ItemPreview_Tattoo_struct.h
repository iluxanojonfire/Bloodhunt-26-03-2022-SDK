// UserDefinedStruct S_ItemPreview_Tattoo.S_ItemPreview_Tattoo
// Size: 0x30 (Inherited: 0x00)
struct FS_ItemPreview_Tattoo {
	enum class ETigerClan Clan_2_03AAA5874E7B3C1F2B68D4914535B2ED; // 0x00(0x01)
	enum class ETigerGender Gender_5_25B10731481CF87FCBC68A817773C170; // 0x01(0x01)
	char pad_2[0x6]; // 0x02(0x06)
	struct TSoftClassPtr<UObject> OutfitClass_8_8A8BC4094C665449E533D395F2221C04; // 0x08(0x28)
};

