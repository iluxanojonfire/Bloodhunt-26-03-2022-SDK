// BlueprintGeneratedClass RangedOnlyStyle.RangedOnlyStyle_C
// Size: 0x48 (Inherited: 0x48)
struct URangedOnlyStyle_C : UTigerWeaponCycleStyle {

	enum class ETigerWeaponSlot DetermineNextWeaponSlot(struct ATigerPlayerController* InPlayerController, enum class ETigerWeaponCycleDirection InDirection); // Function RangedOnlyStyle.RangedOnlyStyle_C.DetermineNextWeaponSlot // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x18490f0
};

