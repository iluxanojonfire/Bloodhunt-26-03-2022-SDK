// BlueprintGeneratedClass TBP_Avatar_Elegant_08.TBP_Avatar_Elegant_08_C
// Size: 0x130 (Inherited: 0x130)
struct UTBP_Avatar_Elegant_08_C : UTigerCharacterIconCustomization {
};

