// UserDefinedEnum E_UI_ArchetypePerkSelectState.E_UI_ArchetypePerkSelectState
enum class E_UI_ArchetypePerkSelectState : uint8 {
	NewEnumerator2 = 0,
	NewEnumerator0 = 1,
	NewEnumerator1 = 2,
	E_UI_MAX = 3
};

