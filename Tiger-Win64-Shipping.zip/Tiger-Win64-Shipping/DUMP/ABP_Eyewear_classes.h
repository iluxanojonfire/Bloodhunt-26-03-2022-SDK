// AnimBlueprintGeneratedClass ABP_Eyewear.ABP_Eyewear_C
// Size: 0x7d0 (Inherited: 0x450)
struct UABP_Eyewear_C : UTigerEyewearAnimInstance {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x450(0x08)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_3; // 0x458(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_2; // 0x560(0x108)
	struct FAnimNode_MeshSpaceRefPose AnimGraphNode_MeshRefPose; // 0x668(0x10)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace; // 0x678(0x20)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone; // 0x698(0x108)
	struct FAnimNode_Root AnimGraphNode_Root; // 0x7a0(0x30)

	void AnimGraph(struct FPoseLink& AnimGraph); // Function ABP_Eyewear.ABP_Eyewear_C.AnimGraph // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x18490f0
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Eyewear_AnimGraphNode_ModifyBone_75CEAA9341A2E5F5BEDC008475ECB15D(); // Function ABP_Eyewear.ABP_Eyewear_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Eyewear_AnimGraphNode_ModifyBone_75CEAA9341A2E5F5BEDC008475ECB15D // (BlueprintEvent) // @ game+0x18490f0
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Eyewear_AnimGraphNode_ModifyBone_CA255A0D46EF5803406ADD9DD0BAF21D(); // Function ABP_Eyewear.ABP_Eyewear_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Eyewear_AnimGraphNode_ModifyBone_CA255A0D46EF5803406ADD9DD0BAF21D // (BlueprintEvent) // @ game+0x18490f0
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Eyewear_AnimGraphNode_ModifyBone_9030559C422CA45A834828A0869B1D21(); // Function ABP_Eyewear.ABP_Eyewear_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Eyewear_AnimGraphNode_ModifyBone_9030559C422CA45A834828A0869B1D21 // (BlueprintEvent) // @ game+0x18490f0
	void ExecuteUbergraph_ABP_Eyewear(int32_t EntryPoint); // Function ABP_Eyewear.ABP_Eyewear_C.ExecuteUbergraph_ABP_Eyewear // (Final|UbergraphFunction) // @ game+0x18490f0
};

