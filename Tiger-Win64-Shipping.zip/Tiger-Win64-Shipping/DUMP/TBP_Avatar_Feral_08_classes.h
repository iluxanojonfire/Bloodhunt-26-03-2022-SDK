// BlueprintGeneratedClass TBP_Avatar_Feral_08.TBP_Avatar_Feral_08_C
// Size: 0x130 (Inherited: 0x130)
struct UTBP_Avatar_Feral_08_C : UTigerCharacterIconCustomization {
};

