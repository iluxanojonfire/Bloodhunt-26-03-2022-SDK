// BlueprintGeneratedClass TBP_Avatar_Reward_02.TBP_Avatar_Reward_02_C
// Size: 0x130 (Inherited: 0x130)
struct UTBP_Avatar_Reward_02_C : UTigerCharacterIconCustomization {
};

