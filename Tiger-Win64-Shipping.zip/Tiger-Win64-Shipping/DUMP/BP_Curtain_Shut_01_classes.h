// BlueprintGeneratedClass BP_Curtain_Shut_01.BP_Curtain_Shut_01_C
// Size: 0x261 (Inherited: 0x261)
struct ABP_Curtain_Shut_01_C : ABP_PropCustomColor_C {
};

