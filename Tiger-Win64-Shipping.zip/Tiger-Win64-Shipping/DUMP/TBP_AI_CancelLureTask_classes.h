// BlueprintGeneratedClass TBP_AI_CancelLureTask.TBP_AI_CancelLureTask_C
// Size: 0xb0 (Inherited: 0xa8)
struct UTBP_AI_CancelLureTask_C : UBTTask_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa8(0x08)

	void ReceiveExecute(struct AActor* OwnerActor); // Function TBP_AI_CancelLureTask.TBP_AI_CancelLureTask_C.ReceiveExecute // (Event|Protected|BlueprintEvent) // @ game+0x18490f0
	void ExecuteUbergraph_TBP_AI_CancelLureTask(int32_t EntryPoint); // Function TBP_AI_CancelLureTask.TBP_AI_CancelLureTask_C.ExecuteUbergraph_TBP_AI_CancelLureTask // (Final|UbergraphFunction) // @ game+0x18490f0
};

