// BlueprintGeneratedClass BP_ElysiumCandle_02.BP_ElysiumCandle_02_C
// Size: 0x265 (Inherited: 0x228)
struct ABP_ElysiumCandle_02_C : AActor {
	struct UPointLightComponent* PointLight_01; // 0x228(0x08)
	struct UStaticMeshComponent* SM_VFX_CandleFlame_01; // 0x230(0x08)
	struct UStaticMeshComponent* SM_VFX_CandleFlame_03; // 0x238(0x08)
	struct UStaticMeshComponent* SM_VFX_CandleFlame_02; // 0x240(0x08)
	struct UPointLightComponent* FlickeringLight1; // 0x248(0x08)
	struct UStaticMeshComponent* SM_MERGED_BP_Candle_01_6; // 0x250(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x258(0x08)
	struct FColor light color; // 0x260(0x04)
	bool Off; // 0x264(0x01)

	float Random from world(int32_t NewParam); // Function BP_ElysiumCandle_02.BP_ElysiumCandle_02_C.Random from world // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x18490f0
	void UserConstructionScript(); // Function BP_ElysiumCandle_02.BP_ElysiumCandle_02_C.UserConstructionScript // (Event|Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x18490f0
};

