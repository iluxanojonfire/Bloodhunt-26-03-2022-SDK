// BlueprintGeneratedClass TBP_Avatar_Royal_11.TBP_Avatar_Royal_10_C
// Size: 0x130 (Inherited: 0x130)
struct UTBP_Avatar_Royal_10_C : UTigerCharacterIconCustomization {
};

