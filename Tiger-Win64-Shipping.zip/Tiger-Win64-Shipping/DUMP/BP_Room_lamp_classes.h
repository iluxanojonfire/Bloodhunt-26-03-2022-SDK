// BlueprintGeneratedClass BP_Room_lamp.BP_Room_lamp_C
// Size: 0x26c (Inherited: 0x228)
struct ABP_Room_lamp_C : AActor {
	struct UTigerSpotLightComponent* TigerSpotLight16_LightComponent0; // 0x228(0x08)
	struct UPointLightComponent* PointLight122_LightComponent0; // 0x230(0x08)
	struct UStaticMeshComponent* SM_Room_lamp_41_StaticMeshComponent0; // 0x238(0x08)
	struct USceneComponent* SharedRoot; // 0x240(0x08)
	float Light Intensity; // 0x248(0x04)
	float Attenuation radius; // 0x24c(0x04)
	bool off; // 0x250(0x01)
	char pad_251[0x7]; // 0x251(0x07)
	struct TArray<struct FLinearColor> Color array; // 0x258(0x10)
	int32_t light color; // 0x268(0x04)

	void UserConstructionScript(); // Function BP_Room_lamp.BP_Room_lamp_C.UserConstructionScript // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x18490f0
};

