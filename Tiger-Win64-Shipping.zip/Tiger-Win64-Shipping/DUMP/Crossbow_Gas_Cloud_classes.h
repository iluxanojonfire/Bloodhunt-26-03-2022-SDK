// BlueprintGeneratedClass Crossbow_Gas_Cloud.Crossbow_Gas_Cloud_C
// Size: 0x518 (Inherited: 0x510)
struct ACrossbow_Gas_Cloud_C : ATigerAreaEffect {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x510(0x08)

	void OnTriggerClient(); // Function Crossbow_Gas_Cloud.Crossbow_Gas_Cloud_C.OnTriggerClient // (Event|Public|BlueprintEvent) // @ game+0x18490f0
	void OnVehicleHit(struct AActor* InActor); // Function Crossbow_Gas_Cloud.Crossbow_Gas_Cloud_C.OnVehicleHit // (Event|Protected|BlueprintEvent) // @ game+0x18490f0
	void ReceiveBeginPlay(); // Function Crossbow_Gas_Cloud.Crossbow_Gas_Cloud_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x18490f0
	void ExecuteUbergraph_Crossbow_Gas_Cloud(int32_t EntryPoint); // Function Crossbow_Gas_Cloud.Crossbow_Gas_Cloud_C.ExecuteUbergraph_Crossbow_Gas_Cloud // (Final|UbergraphFunction|HasDefaults) // @ game+0x18490f0
};

