// AnimBlueprintGeneratedClass ABP_Paperdoll.ABP_Paperdoll_C
// Size: 0xfa1 (Inherited: 0x3c0)
struct UABP_Paperdoll_C : UTigerPaperDollAnimInstance {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x3c0(0x08)
	struct FTigerAnimNode_RandomPlayer TigerAnimGraphNode_RandomPlayer; // 0x3c8(0x98)
	struct FAnimNode_TwoWayBlend AnimGraphNode_TwoWayBlend_4; // 0x460(0xc8)
	struct FAnimNode_TwoWayBlend AnimGraphNode_TwoWayBlend_3; // 0x528(0xc8)
	struct FAnimNode_TwoWayBlend AnimGraphNode_TwoWayBlend_2; // 0x5f0(0xc8)
	struct FAnimNode_TwoWayBlend AnimGraphNode_TwoWayBlend; // 0x6b8(0xc8)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_8; // 0x780(0x80)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_7; // 0x800(0x80)
	struct FTigerFilteredLayeredBlend TigerAnimGraphNode_FilteredLayeredBlending; // 0x880(0xc8)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_6; // 0x948(0x80)
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool; // 0x9c8(0xa0)
	struct FAnimNode_Slot AnimGraphNode_Slot; // 0xa68(0x48)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_5; // 0xab0(0x80)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_4; // 0xb30(0x80)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_3; // 0xbb0(0x80)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_2; // 0xc30(0x80)
	struct FAnimNode_BlendListByEnum AnimGraphNode_BlendListByEnum; // 0xcb0(0xb0)
	struct FAnimNode_PoseBlendNode AnimGraphNode_PoseBlendNode; // 0xd60(0xa0)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer; // 0xe00(0x80)
	struct FAnimNode_Root AnimGraphNode_Root; // 0xe80(0x30)
	struct FAnimNode_ApplyAdditive AnimGraphNode_ApplyAdditive; // 0xeb0(0xc8)
	bool bIsDefaultSequenceList; // 0xf78(0x01)
	char pad_F79[0x3]; // 0xf79(0x03)
	struct FName FaceAnimSlotName00; // 0xf7c(0x08)
	struct FName FaceAnimSlotName01; // 0xf84(0x08)
	struct FName FaceAnimSlotName02; // 0xf8c(0x08)
	struct FName FaceAnimSlotName03; // 0xf94(0x08)
	float Start Position; // 0xf9c(0x04)
	enum class ENUM_UIAnimationMode UIAnimationSelect; // 0xfa0(0x01)

	void AnimGraph(struct FPoseLink& AnimGraph); // Function ABP_Paperdoll.ABP_Paperdoll_C.AnimGraph // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x18490f0
	void FacialAnimations(); // Function ABP_Paperdoll.ABP_Paperdoll_C.FacialAnimations // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x18490f0
	void SelectAnimationSets(struct UTigerAnimationSetCollection* Set Collection); // Function ABP_Paperdoll.ABP_Paperdoll_C.SelectAnimationSets // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x18490f0
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Paperdoll_AnimGraphNode_SequencePlayer_E582EC97449B0B37ADC0ACA05429B4C2(); // Function ABP_Paperdoll.ABP_Paperdoll_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Paperdoll_AnimGraphNode_SequencePlayer_E582EC97449B0B37ADC0ACA05429B4C2 // (BlueprintEvent) // @ game+0x18490f0
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Paperdoll_AnimGraphNode_SequencePlayer_BB1D1FF74A496723387A3B8DBAADF705(); // Function ABP_Paperdoll.ABP_Paperdoll_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Paperdoll_AnimGraphNode_SequencePlayer_BB1D1FF74A496723387A3B8DBAADF705 // (BlueprintEvent) // @ game+0x18490f0
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Paperdoll_AnimGraphNode_SequencePlayer_C42E041348A26E837E668D9F9E6B722F(); // Function ABP_Paperdoll.ABP_Paperdoll_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Paperdoll_AnimGraphNode_SequencePlayer_C42E041348A26E837E668D9F9E6B722F // (BlueprintEvent) // @ game+0x18490f0
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Paperdoll_AnimGraphNode_SequencePlayer_F6119FB64030A2FB3C6041B9E77579B3(); // Function ABP_Paperdoll.ABP_Paperdoll_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Paperdoll_AnimGraphNode_SequencePlayer_F6119FB64030A2FB3C6041B9E77579B3 // (BlueprintEvent) // @ game+0x18490f0
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Paperdoll_TigerAnimGraphNode_RandomPlayer_A8C728FF47A5802CD0C3EAB638BED191(); // Function ABP_Paperdoll.ABP_Paperdoll_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Paperdoll_TigerAnimGraphNode_RandomPlayer_A8C728FF47A5802CD0C3EAB638BED191 // (BlueprintEvent) // @ game+0x18490f0
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Paperdoll_AnimGraphNode_SequencePlayer_CE1E43BE48777820551A1A88BB0B3107(); // Function ABP_Paperdoll.ABP_Paperdoll_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Paperdoll_AnimGraphNode_SequencePlayer_CE1E43BE48777820551A1A88BB0B3107 // (BlueprintEvent) // @ game+0x18490f0
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Paperdoll_AnimGraphNode_SequencePlayer_0C84F26241DF23504C8DBF9B4E6ED9D6(); // Function ABP_Paperdoll.ABP_Paperdoll_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Paperdoll_AnimGraphNode_SequencePlayer_0C84F26241DF23504C8DBF9B4E6ED9D6 // (BlueprintEvent) // @ game+0x18490f0
	void AddSets(struct UTigerAnimationSetCollection* SetCollection); // Function ABP_Paperdoll.ABP_Paperdoll_C.AddSets // (Event|Protected|BlueprintEvent) // @ game+0x18490f0
	void BlueprintUpdateAnimation(float DeltaTimeX); // Function ABP_Paperdoll.ABP_Paperdoll_C.BlueprintUpdateAnimation // (Event|Public|BlueprintEvent) // @ game+0x18490f0
	void BlueprintInitializeAnimation(); // Function ABP_Paperdoll.ABP_Paperdoll_C.BlueprintInitializeAnimation // (Event|Public|BlueprintEvent) // @ game+0x18490f0
	void BlueprintBeginPlay(); // Function ABP_Paperdoll.ABP_Paperdoll_C.BlueprintBeginPlay // (Event|Public|BlueprintEvent) // @ game+0x18490f0
	void ClearProps(struct UAnimMontage* Montage, bool bInterrupted); // Function ABP_Paperdoll.ABP_Paperdoll_C.ClearProps // (BlueprintCallable|BlueprintEvent) // @ game+0x18490f0
	void ExecuteUbergraph_ABP_Paperdoll(int32_t EntryPoint); // Function ABP_Paperdoll.ABP_Paperdoll_C.ExecuteUbergraph_ABP_Paperdoll // (Final|UbergraphFunction) // @ game+0x18490f0
};

