// BlueprintGeneratedClass BP_Weather_Controller.BP_Weather_Controller_C
// Size: 0x440 (Inherited: 0x228)
struct ABP_Weather_Controller_C : ATigerWeatherController {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x228(0x08)
	struct UStaticMeshComponent* sky; // 0x230(0x08)
	struct UExponentialHeightFogComponent* HeavyRain; // 0x238(0x08)
	struct UExponentialHeightFogComponent* DefaultFog; // 0x240(0x08)
	struct UExponentialHeightFogComponent* LightFog; // 0x248(0x08)
	struct UExponentialHeightFogComponent* HeavyFog; // 0x250(0x08)
	struct USceneCaptureComponent2D* TopDownRenderCamera; // 0x258(0x08)
	struct UBillboardComponent* Billboard; // 0x260(0x08)
	struct UChildActorComponent* Wind Directional Source; // 0x268(0x08)
	float Wind Strength; // 0x270(0x04)
	float Rain Rate; // 0x274(0x04)
	float Puddles Amount; // 0x278(0x04)
	int32_t Player Index; // 0x27c(0x04)
	struct TArray<struct UParticleSystemComponent*> Particles Update List; // 0x280(0x10)
	bool Update Player; // 0x290(0x01)
	char pad_291[0x3]; // 0x291(0x03)
	int32_t RandomWeatherInteger; // 0x294(0x04)
	bool bHasSyncedWeather; // 0x298(0x01)
	char pad_299[0x7]; // 0x299(0x07)
	struct UNiagaraComponent* RainSystem; // 0x2a0(0x08)
	bool UseNiagaraRain; // 0x2a8(0x01)
	char pad_2A9[0x7]; // 0x2a9(0x07)
	struct FSoftObjectPath NiagaraRainPath; // 0x2b0(0x18)
	struct UNiagaraSystem* CachedRainEffect; // 0x2c8(0x08)
	float No Rain; // 0x2d0(0x04)
	float Heavy Rain Chance; // 0x2d4(0x04)
	float Light Rain Chance; // 0x2d8(0x04)
	float Lightning Chance; // 0x2dc(0x04)
	float Foggy Chance; // 0x2e0(0x04)
	float Puddles Rings Intensity; // 0x2e4(0x04)
	float AI Sight Modifier; // 0x2e8(0x04)
	float Puddles Wind Tiling; // 0x2ec(0x04)
	bool UseCustomSettings; // 0x2f0(0x01)
	char pad_2F1[0x3]; // 0x2f1(0x03)
	float Wind Speed; // 0x2f4(0x04)
	float Snowfall Rate; // 0x2f8(0x04)
	float Wetness Amount; // 0x2fc(0x04)
	struct UNiagaraComponent* SnowSystem; // 0x300(0x08)
	struct FSoftObjectPath NiagaraSnowPath; // 0x308(0x18)
	struct UNiagaraSystem* CachedSnowEffect; // 0x320(0x08)
	struct TSoftObjectPtr<APostProcessVolume> GlobalPPV Reference; // 0x328(0x28)
	struct FLinearColor Saturation; // 0x350(0x10)
	struct FLinearColor Contrast; // 0x360(0x10)
	struct FLinearColor Gamma; // 0x370(0x10)
	struct FLinearColor Gain; // 0x380(0x10)
	struct FLinearColor Offset; // 0x390(0x10)
	float Temp; // 0x3a0(0x04)
	float Tint; // 0x3a4(0x04)
	float CurrentTime; // 0x3a8(0x04)
	struct FRandomStream LightningSeed; // 0x3ac(0x08)
	char pad_3B4[0x4]; // 0x3b4(0x04)
	struct FTimerHandle LightningTimerHandle; // 0x3b8(0x08)
	bool EnableLightning; // 0x3c0(0x01)
	char pad_3C1[0x3]; // 0x3c1(0x03)
	float LightningIntensity; // 0x3c4(0x04)
	struct TSoftObjectPtr<ASkyLight> SkyLightReference; // 0x3c8(0x28)
	struct TSoftObjectPtr<UTextureCube> OverrideSkyTexture; // 0x3f0(0x28)
	bool OverrideReplicationRange; // 0x418(0x01)
	char pad_419[0x3]; // 0x419(0x03)
	float ReplicationRange; // 0x41c(0x04)
	bool OverrideSky; // 0x420(0x01)
	char pad_421[0x3]; // 0x421(0x03)
	float DefaultSkyLightIntensity; // 0x424(0x04)
	struct FLinearColor DefaultSkyLightColor; // 0x428(0x10)
	int32_t NrStrikes; // 0x438(0x04)
	float LifeTime; // 0x43c(0x04)

	void GetCameraLocation(struct FVector& OutVector); // Function BP_Weather_Controller.BP_Weather_Controller_C.GetCameraLocation // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x18490f0
	void UpdateOverrideSky(struct TArray<struct UObject*>& InLoadedObjects); // Function BP_Weather_Controller.BP_Weather_Controller_C.UpdateOverrideSky // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x18490f0
	void SetWeatherAudioRTPCs(); // Function BP_Weather_Controller.BP_Weather_Controller_C.SetWeatherAudioRTPCs // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x18490f0
	void LightningWave(float InTime, float InLightningLifetime, float InNrLightningStrikes, float& OutWave); // Function BP_Weather_Controller.BP_Weather_Controller_C.LightningWave // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x18490f0
	void Update Prague Sky(struct TArray<struct UObject*>& InLoadedObjects); // Function BP_Weather_Controller.BP_Weather_Controller_C.Update Prague Sky // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x18490f0
	void UpdateGlobalPPV(); // Function BP_Weather_Controller.BP_Weather_Controller_C.UpdateGlobalPPV // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x18490f0
	void UpdateNiagaraSystem(struct UNiagaraComponent* InSystem); // Function BP_Weather_Controller.BP_Weather_Controller_C.UpdateNiagaraSystem // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x18490f0
	void UpdateAllActors(); // Function BP_Weather_Controller.BP_Weather_Controller_C.UpdateAllActors // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x18490f0
	void SetWeatherScenarioParameters(struct UDA_WeatherScenario_C* WeatherScenario); // Function BP_Weather_Controller.BP_Weather_Controller_C.SetWeatherScenarioParameters // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x18490f0
	void SetWeatherScenario(struct UTigerWeatherScenarioData* WeatherScenario); // Function BP_Weather_Controller.BP_Weather_Controller_C.SetWeatherScenario // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x18490f0
	void SetServerWeather(int32_t WeatherOverride); // Function BP_Weather_Controller.BP_Weather_Controller_C.SetServerWeather // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x18490f0
	void UpdateNiagaraWeatherParameters(float Delta); // Function BP_Weather_Controller.BP_Weather_Controller_C.UpdateNiagaraWeatherParameters // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x18490f0
	void UpdateNiagaraCameraAndNiagaraParticles(float Delta); // Function BP_Weather_Controller.BP_Weather_Controller_C.UpdateNiagaraCameraAndNiagaraParticles // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x18490f0
	void SetNPCSightModifier(float Modifier); // Function BP_Weather_Controller.BP_Weather_Controller_C.SetNPCSightModifier // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x18490f0
	void SetWeatherParameters(struct UDA_WeatherScenario_C* WeatherScenario); // Function BP_Weather_Controller.BP_Weather_Controller_C.SetWeatherParameters // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x18490f0
	void UserConstructionScript(); // Function BP_Weather_Controller.BP_Weather_Controller_C.UserConstructionScript // (Event|Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x18490f0
	void OnLoaded_DC0B365449CA096251058EB8A8F31B9F(struct UObject* Loaded); // Function BP_Weather_Controller.BP_Weather_Controller_C.OnLoaded_DC0B365449CA096251058EB8A8F31B9F // (BlueprintCallable|BlueprintEvent) // @ game+0x18490f0
	void OnLoaded_4BFA290045938F3D795460979602E7CF(struct UObject* Loaded); // Function BP_Weather_Controller.BP_Weather_Controller_C.OnLoaded_4BFA290045938F3D795460979602E7CF // (BlueprintCallable|BlueprintEvent) // @ game+0x18490f0
	void OnLoaded_20562D87404E74DCF4D9B889FFC5C3D6(struct UObject* Loaded); // Function BP_Weather_Controller.BP_Weather_Controller_C.OnLoaded_20562D87404E74DCF4D9B889FFC5C3D6 // (BlueprintCallable|BlueprintEvent) // @ game+0x18490f0
	void OnLoaded_7559EC034D4951730F8F999663014852(struct UObject* Loaded); // Function BP_Weather_Controller.BP_Weather_Controller_C.OnLoaded_7559EC034D4951730F8F999663014852 // (BlueprintCallable|BlueprintEvent) // @ game+0x18490f0
	void ReceiveBeginPlay(); // Function BP_Weather_Controller.BP_Weather_Controller_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x18490f0
	void ReceiveTick(float DeltaSeconds); // Function BP_Weather_Controller.BP_Weather_Controller_C.ReceiveTick // (Event|Public|BlueprintEvent) // @ game+0x18490f0
	void HandleOnWeatherSenarioChangedEvent(struct UTigerWeatherScenarioData* WeatherScenarioData); // Function BP_Weather_Controller.BP_Weather_Controller_C.HandleOnWeatherSenarioChangedEvent // (BlueprintCallable|BlueprintEvent) // @ game+0x18490f0
	void TigerSetFogDensity(float FogDensity); // Function BP_Weather_Controller.BP_Weather_Controller_C.TigerSetFogDensity // (BlueprintCallable|BlueprintEvent) // @ game+0x18490f0
	void Lightning(); // Function BP_Weather_Controller.BP_Weather_Controller_C.Lightning // (BlueprintCallable|BlueprintEvent) // @ game+0x18490f0
	void ExecuteUbergraph_BP_Weather_Controller(int32_t EntryPoint); // Function BP_Weather_Controller.BP_Weather_Controller_C.ExecuteUbergraph_BP_Weather_Controller // (Final|UbergraphFunction|HasDefaults) // @ game+0x18490f0
};

