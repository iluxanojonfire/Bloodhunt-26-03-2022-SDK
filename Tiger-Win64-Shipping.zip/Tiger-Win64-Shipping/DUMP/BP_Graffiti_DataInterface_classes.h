// BlueprintGeneratedClass BP_Graffiti_DataInterface.BP_Graffiti_DataInterface_C
// Size: 0x28 (Inherited: 0x28)
struct UBP_Graffiti_DataInterface_C : UObject {

	void GetPaintOverMaterial(int32_t InIndex, struct UMaterialInterface*& OutMaterial); // Function BP_Graffiti_DataInterface.BP_Graffiti_DataInterface_C.GetPaintOverMaterial // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x18490f0
	void GetMaterial(int32_t InIndex, struct UMaterialInterface*& OutMaterial); // Function BP_Graffiti_DataInterface.BP_Graffiti_DataInterface_C.GetMaterial // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x18490f0
};

