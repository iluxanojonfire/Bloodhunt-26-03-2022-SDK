// BlueprintGeneratedClass BPI_MenuChangeInterface.BPI_MenuChangeInterface_C
// Size: 0x28 (Inherited: 0x28)
struct UBPI_MenuChangeInterface_C : UInterface {

	void On Menu Changed(struct TSoftClassPtr<UObject>& NewMenuWidget); // Function BPI_MenuChangeInterface.BPI_MenuChangeInterface_C.On Menu Changed // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x18490f0
};

