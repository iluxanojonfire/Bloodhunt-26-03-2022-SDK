// BlueprintGeneratedClass DA_WeatherScenarioLightRainHeavyFog.DA_WeatherScenarioLightRainHeavyFog_C
// Size: 0xf5 (Inherited: 0xf5)
struct UDA_WeatherScenarioLightRainHeavyFog_C : UDA_WeatherScenario_C {
};

