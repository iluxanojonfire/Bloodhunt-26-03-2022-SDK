// BlueprintGeneratedClass Explosion_Test.Explosion_Test_C
// Size: 0x520 (Inherited: 0x510)
struct AExplosion_Test_C : ATigerAreaEffect {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x510(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x518(0x08)

	void OnTriggerClient(); // Function Explosion_Test.Explosion_Test_C.OnTriggerClient // (Event|Public|BlueprintEvent) // @ game+0x18490f0
	void ExecuteUbergraph_Explosion_Test(int32_t EntryPoint); // Function Explosion_Test.Explosion_Test_C.ExecuteUbergraph_Explosion_Test // (Final|UbergraphFunction) // @ game+0x18490f0
};

