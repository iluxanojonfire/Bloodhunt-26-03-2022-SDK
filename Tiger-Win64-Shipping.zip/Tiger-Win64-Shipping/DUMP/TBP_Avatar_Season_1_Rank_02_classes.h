// BlueprintGeneratedClass TBP_Avatar_Season_1_Rank_02.TBP_Avatar_Season_1_Rank_02_C
// Size: 0x130 (Inherited: 0x130)
struct UTBP_Avatar_Season_1_Rank_02_C : UTigerCharacterIconCustomization {
};

