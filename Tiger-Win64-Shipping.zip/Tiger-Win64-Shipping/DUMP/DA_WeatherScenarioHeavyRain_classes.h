// BlueprintGeneratedClass DA_WeatherScenarioHeavyRain.DA_WeatherScenarioHeavyRain_C
// Size: 0xf5 (Inherited: 0xf5)
struct UDA_WeatherScenarioHeavyRain_C : UDA_WeatherScenario_C {
};

