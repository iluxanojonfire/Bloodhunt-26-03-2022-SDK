// BlueprintGeneratedClass SM_Ely_Brazier_01.SM_Ely_Brazier_01_C
// Size: 0x2a4 (Inherited: 0x228)
struct ASM_Ely_Brazier_01_C : AActor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x228(0x08)
	struct UTigerSpotLightComponent* Spotlight_Bottom_02; // 0x230(0x08)
	struct UNiagaraComponent* NS_VFX_ENV_Fire9_NiagaraComponent0; // 0x238(0x08)
	struct UTigerSpotLightComponent* Spotlight_Top; // 0x240(0x08)
	struct UAkComponent* Brazier_Burning3_AkAudioComponent0; // 0x248(0x08)
	struct UTigerSpotLightComponent* Spotlight_Bottom_01; // 0x250(0x08)
	struct UPointLightComponent* Brazier_Fill; // 0x258(0x08)
	struct UStaticMeshComponent* SM_Ely_Brazier_9_StaticMeshComponent0; // 0x260(0x08)
	struct USceneComponent* SharedRoot; // 0x268(0x08)
	float Point light intensity; // 0x270(0x04)
	float Attenuation radius; // 0x274(0x04)
	float Rotation bottom light 1; // 0x278(0x04)
	float Rotation bottom light 2; // 0x27c(0x04)
	float Rotation top light; // 0x280(0x04)
	float Cone angle; // 0x284(0x04)
	float Spotlight intensity; // 0x288(0x04)
	bool Enable bottom light 1; // 0x28c(0x01)
	bool Enable bottom light 2; // 0x28d(0x01)
	char pad_28E[0x2]; // 0x28e(0x02)
	struct TArray<struct FLinearColor> Color; // 0x290(0x10)
	int32_t Color Selection; // 0x2a0(0x04)

	void UserConstructionScript(); // Function SM_Ely_Brazier_01.SM_Ely_Brazier_01_C.UserConstructionScript // (Event|Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x18490f0
	void ReceiveBeginPlay(); // Function SM_Ely_Brazier_01.SM_Ely_Brazier_01_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x18490f0
	void ExecuteUbergraph_SM_Ely_Brazier_01(int32_t EntryPoint); // Function SM_Ely_Brazier_01.SM_Ely_Brazier_01_C.ExecuteUbergraph_SM_Ely_Brazier_01 // (Final|UbergraphFunction|HasDefaults) // @ game+0x18490f0
};

